package com.safar.app.views.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// ══════════════════════════════════════════════════════════════════════════════
// SAFAR Design System - Premium Color Palette
// Inspired by Uber, Careem, Yango
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Centralized color system for SAFAR app
 * Supports both light and dark themes
 */
object SafarColors {
    // Primary brand color - Golden/Yellow accent
    val primary = Color(0xFFFFC107)
    val primaryVariant = Color(0xFFFFD54F)
    val primaryDark = Color(0xFFF9A825)
    
    // Semantic colors
    val success = Color(0xFF4CAF50)
    val successLight = Color(0xFF81C784)
    val error = Color(0xFFE53935)
    val errorLight = Color(0xFFEF5350)
    val warning = Color(0xFFFF9800)
    val info = Color(0xFF2196F3)
    
    // Dark theme surfaces
    val surfaceDark = Color(0xFF121212)
    val surfaceElevatedDark = Color(0xFF1E1E1E)
    val surfaceCardDark = Color(0xFF252525)
    val surfaceOverlayDark = Color(0xFF2C2C2C)
    
    // Light theme surfaces
    val surfaceLight = Color(0xFFFAFAFA)
    val surfaceElevatedLight = Color(0xFFFFFFFF)
    val surfaceCardLight = Color(0xFFF5F5F5)
    val surfaceOverlayLight = Color(0xFFEEEEEE)
    
    // Text colors - Dark theme
    val textPrimaryDark = Color(0xFFFFFFFF)
    val textSecondaryDark = Color(0xFFB3B3B3)
    val textTertiaryDark = Color(0xFF757575)
    val textDisabledDark = Color(0xFF4A4A4A)
    
    // Text colors - Light theme
    val textPrimaryLight = Color(0xFF1A1A1A)
    val textSecondaryLight = Color(0xFF666666)
    val textTertiaryLight = Color(0xFF999999)
    val textDisabledLight = Color(0xFFBDBDBD)
    
    // Dividers
    val dividerDark = Color(0xFF2E2E2E)
    val dividerLight = Color(0xFFE0E0E0)
    
    // Dynamic properties based on theme
    private var isDarkMode = true
    
    val surface: Color get() = if (isDarkMode) surfaceDark else surfaceLight
    val surfaceElevated: Color get() = if (isDarkMode) surfaceElevatedDark else surfaceElevatedLight
    val surfaceCard: Color get() = if (isDarkMode) surfaceCardDark else surfaceCardLight
    val surfaceOverlay: Color get() = if (isDarkMode) surfaceOverlayDark else surfaceOverlayLight
    
    val textPrimary: Color get() = if (isDarkMode) textPrimaryDark else textPrimaryLight
    val textSecondary: Color get() = if (isDarkMode) textSecondaryDark else textSecondaryLight
    val textTertiary: Color get() = if (isDarkMode) textTertiaryDark else textTertiaryLight
    val textDisabled: Color get() = if (isDarkMode) textDisabledDark else textDisabledLight
    
    val divider: Color get() = if (isDarkMode) dividerDark else dividerLight
    
    fun setDarkMode(dark: Boolean) {
        isDarkMode = dark
    }
}

// Legacy color references for backward compatibility
val SafarYellow = SafarColors.primary
val SafarDarkSurface = SafarColors.surfaceDark
val SafarDarkCard = SafarColors.surfaceCardDark
val SafarTextPrimary = SafarColors.textPrimaryDark
val SafarTextSecondary = SafarColors.textSecondaryDark
val SafarDivider = SafarColors.dividerDark

// ══════════════════════════════════════════════════════════════════════════════
// Material 3 Color Schemes
// ══════════════════════════════════════════════════════════════════════════════

private val SafarDarkColorScheme = darkColorScheme(
    primary = SafarColors.primary,
    onPrimary = Color(0xFF1A1A1A),
    primaryContainer = SafarColors.primaryDark,
    onPrimaryContainer = Color.White,
    
    secondary = SafarColors.primaryVariant,
    onSecondary = Color(0xFF1A1A1A),
    secondaryContainer = Color(0xFF3D3D3D),
    onSecondaryContainer = Color.White,
    
    tertiary = SafarColors.info,
    onTertiary = Color.White,
    
    background = SafarColors.surfaceDark,
    onBackground = SafarColors.textPrimaryDark,
    
    surface = SafarColors.surfaceDark,
    onSurface = SafarColors.textPrimaryDark,
    surfaceVariant = SafarColors.surfaceElevatedDark,
    onSurfaceVariant = SafarColors.textSecondaryDark,
    
    error = SafarColors.error,
    onError = Color.White,
    
    outline = SafarColors.dividerDark,
    outlineVariant = SafarColors.surfaceCardDark
)

private val SafarLightColorScheme = lightColorScheme(
    primary = SafarColors.primaryDark,
    onPrimary = Color.White,
    primaryContainer = SafarColors.primary,
    onPrimaryContainer = Color(0xFF1A1A1A),
    
    secondary = SafarColors.primaryVariant,
    onSecondary = Color(0xFF1A1A1A),
    secondaryContainer = Color(0xFFFFECB3),
    onSecondaryContainer = Color(0xFF1A1A1A),
    
    tertiary = SafarColors.info,
    onTertiary = Color.White,
    
    background = SafarColors.surfaceLight,
    onBackground = SafarColors.textPrimaryLight,
    
    surface = SafarColors.surfaceLight,
    onSurface = SafarColors.textPrimaryLight,
    surfaceVariant = SafarColors.surfaceElevatedLight,
    onSurfaceVariant = SafarColors.textSecondaryLight,
    
    error = SafarColors.error,
    onError = Color.White,
    
    outline = SafarColors.dividerLight,
    outlineVariant = SafarColors.surfaceCardLight
)

// ══════════════════════════════════════════════════════════════════════════════
// Typography System
// ══════════════════════════════════════════════════════════════════════════════

import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.*
import androidx.compose.ui.unit.sp

// Google Fonts - Inter for clean modern look
val SafarFontFamily = FontFamily(
    Font(resId = android.R.font.sans_serif, weight = FontWeight.Normal),
    Font(resId = android.R.font.sans_serif_medium, weight = FontWeight.Medium),
    Font(resId = android.R.font.sans_serif, weight = FontWeight.SemiBold),
    Font(resId = android.R.font.sans_serif, weight = FontWeight.Bold)
)

val SafarTypography = Typography(
    // Display styles
    displayLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 57.sp,
        lineHeight = 64.sp,
        letterSpacing = (-0.25).sp
    ),
    displayMedium = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 45.sp,
        lineHeight = 52.sp
    ),
    displaySmall = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 36.sp,
        lineHeight = 44.sp
    ),
    
    // Headline styles
    headlineLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 32.sp,
        lineHeight = 40.sp
    ),
    headlineMedium = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        lineHeight = 36.sp
    ),
    headlineSmall = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 24.sp,
        lineHeight = 32.sp
    ),
    
    // Title styles
    titleLarge = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp,
        lineHeight = 28.sp
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.15.sp
    ),
    titleSmall = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.1.sp
    ),
    
    // Body styles
    bodyLarge = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.5.sp
    ),
    bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.25.sp
    ),
    bodySmall = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.4.sp
    ),
    
    // Label styles
    labelLarge = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.1.sp
    ),
    labelMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.5.sp
    ),
    labelSmall = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.5.sp
    )
)

// ══════════════════════════════════════════════════════════════════════════════
// Shape System
// ══════════════════════════════════════════════════════════════════════════════

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

val SafarShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

// ══════════════════════════════════════════════════════════════════════════════
// Theme Composable
// ══════════════════════════════════════════════════════════════════════════════

@Composable
fun SafarTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    // Update the color system
    SafarColors.setDarkMode(darkTheme)
    
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context)
            else dynamicLightColorScheme(context)
        }
        darkTheme -> SafarDarkColorScheme
        else -> SafarLightColorScheme
    }
    
    // Set system bars color
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = Color.Transparent.toArgb()
            window.navigationBarColor = Color.Transparent.toArgb()
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !darkTheme
                isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }
    
    MaterialTheme(
        colorScheme = colorScheme,
        typography = SafarTypography,
        shapes = SafarShapes,
        content = content
    )
}

// ══════════════════════════════════════════════════════════════════════════════
// Dimension System (8dp Grid)
// ══════════════════════════════════════════════════════════════════════════════

object SafarDimens {
    // Spacing
    val spacingXxs = 2.dp
    val spacingXs = 4.dp
    val spacingSm = 8.dp
    val spacingMd = 12.dp
    val spacingLg = 16.dp
    val spacingXl = 20.dp
    val spacingXxl = 24.dp
    val spacing3xl = 32.dp
    val spacing4xl = 40.dp
    val spacing5xl = 48.dp
    
    // Padding
    val paddingScreen = 16.dp
    val paddingCard = 16.dp
    val paddingButton = 12.dp
    
    // Corner radius
    val radiusXs = 4.dp
    val radiusSm = 8.dp
    val radiusMd = 12.dp
    val radiusLg = 16.dp
    val radiusXl = 20.dp
    val radiusXxl = 24.dp
    val radiusFull = 100.dp
    
    // Icon sizes
    val iconXs = 12.dp
    val iconSm = 16.dp
    val iconMd = 20.dp
    val iconLg = 24.dp
    val iconXl = 32.dp
    val iconXxl = 48.dp
    
    // Button heights
    val buttonHeightSm = 36.dp
    val buttonHeightMd = 44.dp
    val buttonHeightLg = 52.dp
    val buttonHeightXl = 56.dp
    
    // Card elevation
    val elevationNone = 0.dp
    val elevationSm = 2.dp
    val elevationMd = 4.dp
    val elevationLg = 8.dp
    val elevationXl = 12.dp
    val elevationXxl = 16.dp
}

package com.safar.app.views.activities

import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.safar.app.views.ui.screens.LocationPickerScreen
import com.safar.app.views.ui.theme.SafarTheme

class LocationPickerStateHolder {
    var placeName        by mutableStateOf("")
    var placeNameHint    by mutableStateOf("Move map to detect, or type a name")
    var isConfirmEnabled by mutableStateOf(false)
    // Java accesses via auto-generated methods — NO explicit functions needed:
    //   stateHolder.getPlaceName()           stateHolder.setPlaceName(x)
    //   stateHolder.getPlaceNameHint()       stateHolder.setPlaceNameHint(x)
    //   stateHolder.isConfirmEnabled()       stateHolder.setConfirmEnabled(x)
}

fun LocationPickerActivity.setupComposeUI(
    stateHolder : LocationPickerStateHolder,
    title       : String
) {
    setContent {
        SafarTheme(darkTheme = true) {
            LocationPickerScreen(
                title             = title,
                placeName         = stateHolder.placeName,
                isConfirmEnabled  = stateHolder.isConfirmEnabled,
                onPlaceNameChange = { stateHolder.placeName = it },
                onSearchQuery     = { query -> handleSearch(query) },
                onZoomIn          = { handleZoomIn() },
                onZoomOut         = { handleZoomOut() },
                onMyLocation      = { handleMyLocation() },
                onConfirm         = { handleConfirm(stateHolder.placeName) },
                onBack            = { onBackPressed() },
                onMapReady        = { mapView -> bindMapView(mapView) }
            )
        }
    }
}

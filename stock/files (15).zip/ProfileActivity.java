package com.safar.app.views.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.safar.app.firebase.FirebaseManager;
import com.safar.app.models.User;
import com.safar.app.utils.SessionManager;

public class ProfileActivity extends AppCompatActivity {

    private ProfileStateHolder stateHolder;
    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        session     = new SessionManager(this);
        stateHolder = new ProfileStateHolder();
        ProfileBridgeKt.setupComposeUI(this, stateHolder);
        loadProfile();
    }

    private void loadProfile() {
        String uid = FirebaseAuth.getInstance().getCurrentUser() != null
                ? FirebaseAuth.getInstance().getCurrentUser().getUid() : null;
        if (uid == null) return;

        stateHolder.updateName(session.getUserName()  != null ? session.getUserName()  : "");
        stateHolder.updatePhone(session.getUserPhone() != null ? session.getUserPhone() : "");

        FirebaseManager.getInstance().getUserRef(uid).get()
                .addOnSuccessListener(snapshot -> {
                    User user = snapshot.getValue(User.class);
                    if (user != null) {
                        stateHolder.updateName(user.getName()   != null ? user.getName()  : "");
                        stateHolder.updatePhone(user.getPhone() != null ? user.getPhone() : "");
                        stateHolder.updateTotalRides(user.getTotalRides());
                        if (user.getRatingCount() > 0) {
                            stateHolder.updateRating((float) user.getRating(), user.getRatingCount());
                        }
                    }
                });
    }

    public void navigateToMyRides() {
        startActivity(new Intent(this, MyAdsActivity.class));
    }

    public void showLogoutDialog() {
        new android.app.AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Are you sure you want to logout?")
                .setPositiveButton("Logout", (d, w) -> {
                    session.logout(this);
                    Intent i = new Intent(this, PhoneAuthActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    public void handleGithub() {
        startActivity(new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://github.com/sa1ffffff")));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { onBackPressed(); return true; }
        return super.onOptionsItemSelected(item);
    }
}

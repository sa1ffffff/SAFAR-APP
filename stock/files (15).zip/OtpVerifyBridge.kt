package com.safar.app.views.activities

import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.safar.app.views.ui.screens.OtpVerifyScreen
import com.safar.app.views.ui.theme.SafarTheme

class OtpVerifyStateHolder {
    var otpValue      by mutableStateOf("")
    var resendSeconds by mutableStateOf(60)
    var isLoading     by mutableStateOf(false)
    var phoneNumber   by mutableStateOf("")
    // Java accesses via auto-generated methods:
    //   stateHolder.getOtpValue()            stateHolder.setOtpValue(x)
    //   stateHolder.getResendSeconds()        stateHolder.setResendSeconds(x)
    //   stateHolder.isLoading()               stateHolder.setLoading(x)
    //   stateHolder.getPhoneNumber()          stateHolder.setPhoneNumber(x)
}

fun OtpVerifyActivity.setupComposeUI(stateHolder: OtpVerifyStateHolder) {
    setContent {
        SafarTheme(darkTheme = true) {
            OtpVerifyScreen(
                phoneNumber   = stateHolder.phoneNumber,
                otpValue      = stateHolder.otpValue,
                resendSeconds = stateHolder.resendSeconds,
                isLoading     = stateHolder.isLoading,
                onOtpChange   = { stateHolder.otpValue = it },
                onVerify      = { handleVerify(stateHolder.otpValue) },
                onResend      = { handleResend() }
            )
        }
    }
}

package com.safar.app.views.activities

import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.safar.app.views.ui.screens.PostAdScreen
import com.safar.app.views.ui.screens.PostAdUiState
import com.safar.app.views.ui.theme.SafarTheme

class PostAdStateHolder {
    var state by mutableStateOf(PostAdUiState())
        private set
    // Java reads via: stateHolder.getState()  ← auto-generated, no clash

    fun updateLoading(loading: Boolean)    { state = state.copy(isLoading = loading) }
    fun updateOrigin(address: String)      { state = state.copy(originAddress = address, originPicked = true) }
    fun updateDestination(address: String) { state = state.copy(destAddress = address, destPicked = true) }
    fun updateDateTimeLabel(label: String) { state = state.copy(dateTimeLabel = label, dateTimePicked = true) }
    fun updatePhone(phone: String)         { state = state.copy(phone = phone) }
    fun updateSeats(s: String)             { state = state.copy(seats = s) }
    fun updateVehicle(v: String)           { state = state.copy(vehicle = v) }
    fun updateNotes(n: String)             { state = state.copy(notes = n) }
}

fun PostAdActivity.setupComposeUI(stateHolder: PostAdStateHolder) {
    setContent {
        SafarTheme(darkTheme = true) {
            PostAdScreen(
                state           = stateHolder.state,
                onPhoneChange   = { stateHolder.updatePhone(it) },
                onSeatsChange   = { stateHolder.updateSeats(it) },
                onVehicleChange = { stateHolder.updateVehicle(it) },
                onNotesChange   = { stateHolder.updateNotes(it) },
                onPickOrigin    = { launchOriginPicker() },
                onPickDest      = { launchDestPicker() },
                onPickDateTime  = { showDatePicker() },
                onPost          = { validateAndPost() },
                onBack          = { onBackPressed() }
            )
        }
    }
}

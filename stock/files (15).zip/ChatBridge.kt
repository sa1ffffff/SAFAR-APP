package com.safar.app.views.activities

import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf
import com.safar.app.views.ui.screens.ChatMessage
import com.safar.app.views.ui.screens.ChatScreen
import com.safar.app.views.ui.theme.SafarTheme

class ChatStateHolder {
    val messages  = mutableStateListOf<ChatMessage>()
    var isLoading by mutableStateOf(false)
    // Java accesses isLoading via: stateHolder.isLoading() / stateHolder.setLoading(x)
    // messages is a val — Java calls stateHolder.getMessages() to get the list reference

    fun addMessage(msg: ChatMessage) { messages.add(msg) }

    fun setMessages(list: List<ChatMessage>) {
        messages.clear()
        messages.addAll(list)
    }
    // NOTE: setMessages() does NOT clash because `val messages` only generates a getter,
    // not a setter. Only var properties generate setters.
}

fun ChatActivity.setupComposeUI(
    stateHolder   : ChatStateHolder,
    peerName      : String,
    disclaimerText: String
) {
    setContent {
        SafarTheme(darkTheme = true) {
            ChatScreen(
                peerName       = peerName,
                messages       = stateHolder.messages,
                disclaimerText = disclaimerText,
                onSend         = { text -> handleSend(text) },
                onBack         = { onBackPressed() }
            )
        }
    }
}

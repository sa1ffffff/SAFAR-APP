package com.safar.app.views.activities

import android.widget.FrameLayout
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentContainerView
import com.safar.app.R
import com.safar.app.views.ui.theme.SafarDarkSurface
import com.safar.app.views.ui.theme.SafarTextSecondary
import com.safar.app.views.ui.theme.SafarTheme
import com.safar.app.views.ui.theme.SafarYellow

sealed class MainTab(val index: Int, val label: String, val icon: ImageVector) {
    object Map     : MainTab(0, "Map",    Icons.Rounded.Map)
    object Rides   : MainTab(1, "Rides",  Icons.Rounded.DirectionsCar)
    object Inbox   : MainTab(2, "Inbox",  Icons.Rounded.Inbox)
    object Profile : MainTab(3, "Profile",Icons.Rounded.Person)
}

private val mainTabs = listOf(MainTab.Map, MainTab.Rides, MainTab.Inbox, MainTab.Profile)

class MainStateHolder {
    var selectedTab by mutableStateOf(0)
    // Java accesses via:
    //   stateHolder.getSelectedTab()   ← auto-generated getter
    //   stateHolder.setSelectedTab(x)  ← auto-generated setter
}

@OptIn(ExperimentalMaterial3Api::class)
fun MainActivity.setupComposeUI(stateHolder: MainStateHolder) {
    setContent {
        SafarTheme(darkTheme = true) {
            androidx.compose.foundation.layout.Column(
                modifier = Modifier.fillMaxSize()
            ) {
                androidx.compose.ui.viewinterop.AndroidView(
                    factory = { ctx ->
                        FragmentContainerView(ctx).apply {
                            id = R.id.fragmentContainer
                            layoutParams = FrameLayout.LayoutParams(
                                FrameLayout.LayoutParams.MATCH_PARENT,
                                FrameLayout.LayoutParams.MATCH_PARENT
                            )
                        }
                    },
                    modifier = Modifier.weight(1f)
                )

                NavigationBar(
                    containerColor = SafarDarkSurface,
                    tonalElevation = 0.dp
                ) {
                    mainTabs.forEach { tab ->
                        val selected = stateHolder.selectedTab == tab.index
                        NavigationBarItem(
                            selected = selected,
                            onClick  = { onTabSelected(tab.index) },
                            icon     = { Icon(tab.icon, contentDescription = tab.label) },
                            label    = { Text(tab.label, style = MaterialTheme.typography.labelSmall) },
                            colors   = NavigationBarItemDefaults.colors(
                                selectedIconColor   = SafarYellow,
                                selectedTextColor   = SafarYellow,
                                unselectedIconColor = SafarTextSecondary,
                                unselectedTextColor = SafarTextSecondary,
                                indicatorColor      = SafarYellow.copy(alpha = 0.15f)
                            )
                        )
                    }
                }
            }
        }
    }
}

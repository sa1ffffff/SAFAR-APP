package com.safar.app.views.activities

import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.safar.app.views.ui.screens.ProfileScreen
import com.safar.app.views.ui.screens.ProfileUiState
import com.safar.app.views.ui.theme.SafarTheme

class ProfileStateHolder {
    var state by mutableStateOf(ProfileUiState())
        private set
    // Java reads via: stateHolder.getState()  ← auto-generated getter for var state
    // private set means Java cannot call stateHolder.setState() — correct, use updaters below

    // These updater functions do NOT clash — their names differ from auto-generated
    // getState()/setState() because they operate on *fields inside* the state object
    fun updateLoading(loading: Boolean)         { state = state.copy(isLoading = loading) }
    fun updateName(name: String)                { state = state.copy(name = name) }
    fun updatePhone(phone: String)              { state = state.copy(phone = phone) }
    fun updateTotalRides(n: Int)                { state = state.copy(totalRides = n) }
    fun updateRating(rating: Float, count: Int) { state = state.copy(rating = rating, ratingCount = count) }
}

fun ProfileActivity.setupComposeUI(stateHolder: ProfileStateHolder) {
    setContent {
        SafarTheme(darkTheme = false) {
            ProfileScreen(
                state     = stateHolder.state,
                onMyRides = { navigateToMyRides() },
                onLogout  = { showLogoutDialog() },
                onBack    = { onBackPressed() }
            )
        }
    }
}

package com.safar.app.views.activities

import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.safar.app.views.ui.screens.SafetyScreen
import com.safar.app.views.ui.theme.SafarTheme

class SafetyStateHolder {
    var isChecked by mutableStateOf(false)
    // Java accesses via: stateHolder.isChecked()       ← auto-generated getter
    //                    stateHolder.setChecked(true)  ← auto-generated setter
}

fun SafetyActivity.setupComposeUI(stateHolder: SafetyStateHolder) {
    setContent {
        SafarTheme(darkTheme = true) {
            SafetyScreen(
                isChecked       = stateHolder.isChecked,
                onCheckedChange = { stateHolder.isChecked = it },
                onIUnderstand   = { handleIUnderstand() }
            )
        }
    }
}

package com.safar.app.views.activities

import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.safar.app.views.ui.screens.AdDetailScreen
import com.safar.app.views.ui.screens.AdDetailUiState
import com.safar.app.views.ui.screens.JoinRequest
import com.safar.app.views.ui.theme.SafarTheme

class AdDetailStateHolder {
    var state by mutableStateOf(AdDetailUiState())
        private set

    fun updateLoading(loading: Boolean)         { state = state.copy(isLoading = loading) }
    fun updateOrigin(origin: String)            { state = state.copy(origin = origin) }
    fun updateDestination(dest: String)         { state = state.copy(destination = dest) }
    fun updateDepartureTime(time: String)       { state = state.copy(departureTime = time) }
    fun updateSeats(seats: String)              { state = state.copy(seats = seats) }
    fun updatePostedBy(name: String)            { state = state.copy(postedBy = name) }
    fun updateVehicle(vehicle: String)          { state = state.copy(vehicle = vehicle) }
    fun updateStatus(status: String)            { state = state.copy(status = status) }
    fun updateNotes(notes: String)              { state = state.copy(notes = notes) }
    fun updateIsOwner(isOwner: Boolean)         { state = state.copy(isOwner = isOwner) }
    fun updateRequests(list: List<JoinRequest>) { state = state.copy(joinRequests = list) }
}

fun AdDetailActivity.setupComposeUI(stateHolder: AdDetailStateHolder) {
    setContent {
        SafarTheme(darkTheme = false) {
            AdDetailScreen(
                uiState         = stateHolder.state,
                onBack          = { onBackPressed() },
                onMarkFilled    = { handleMarkFilled() },
                onDeleteAd      = { handleDeleteAd() },
                onSendRequest   = { handleSendRequest() },
                onAcceptRequest = { requestId -> handleAccept(requestId) },
                onRejectRequest = { requestId -> handleReject(requestId) }
            )
        }
    }
}

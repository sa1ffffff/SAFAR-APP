package com.safar.app.views.activities

import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.safar.app.views.ui.screens.MyAdsScreen
import com.safar.app.views.ui.screens.MyAdsUiState
import com.safar.app.views.ui.screens.RideAdUi
import com.safar.app.views.ui.theme.SafarTheme

class MyAdsStateHolder {
    var state by mutableStateOf(MyAdsUiState())
        private set

    fun updateLoading(loading: Boolean)  { state = state.copy(isLoading = loading) }
    fun updateAds(ads: List<RideAdUi>)   { state = state.copy(ads = ads, isLoading = false) }
}

fun MyAdsActivity.setupComposeUI(stateHolder: MyAdsStateHolder) {
    setContent {
        SafarTheme(darkTheme = true) {
            MyAdsScreen(
                state     = stateHolder.state,
                onAdClick = { adId -> navigateToAdDetail(adId) },
                onBack    = { onBackPressed() }
            )
        }
    }
}

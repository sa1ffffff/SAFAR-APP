package com.safar.app.views.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.safar.app.models.RideAd;
import com.safar.app.presenters.AdsPresenter;
import com.safar.app.utils.AppConstants;
import com.safar.app.views.ui.screens.RideAdUi;

import java.util.ArrayList;
import java.util.List;

public class MyAdsActivity extends AppCompatActivity implements AdsPresenter.AdsView {

    private MyAdsStateHolder stateHolder;
    private AdsPresenter     presenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        stateHolder = new MyAdsStateHolder();
        MyAdsBridgeKt.setupComposeUI(this, stateHolder);

        String uid = FirebaseAuth.getInstance().getCurrentUser() != null
                ? FirebaseAuth.getInstance().getCurrentUser().getUid() : null;
        presenter = new AdsPresenter(this);
        if (uid != null) presenter.loadMyAds(uid);
    }

    public void navigateToAdDetail(String adId) {
        Intent i = new Intent(this, AdDetailActivity.class);
        i.putExtra(AppConstants.KEY_AD_ID, adId);
        startActivity(i);
    }

    @Override
    public void onAdsLoaded(List<RideAd> ads) {
        List<RideAdUi> uiList = new ArrayList<>();
        for (RideAd ad : ads) {
            uiList.add(new RideAdUi(
                    ad.getAdId()           != null ? ad.getAdId()           : "",
                    ad.getOrigin()         != null ? ad.getOrigin()         : "",
                    ad.getDestination()    != null ? ad.getDestination()    : "",
                    ad.getDepartureTime(),
                    ad.getAvailableSeats(),
                    ad.getVehicleDetails() != null ? ad.getVehicleDetails() : "",
                    ad.getStatus()         != null ? ad.getStatus()         : "Open"
            ));
        }
        stateHolder.updateAds(uiList);
    }

    @Override public void onAdPosted(String adId) {}
    @Override public void onAdDeleted() {}
    @Override public void onError(String message) {}

    @Override
    public void onLoading(boolean isLoading) {
        stateHolder.updateLoading(isLoading);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { onBackPressed(); return true; }
        return super.onOptionsItemSelected(item);
    }
}

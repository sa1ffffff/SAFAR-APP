package com.safar.app.views.activities

import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.safar.app.views.ui.screens.PhoneAuthScreen
import com.safar.app.views.ui.theme.SafarTheme

class PhoneAuthStateHolder {
    var phone       by mutableStateOf("")
    var countryCode by mutableStateOf("+92")
    // Java accesses via:
    //   stateHolder.getPhone()           ← auto-generated
    //   stateHolder.getCountryCode()     ← auto-generated
    //   stateHolder.setCountryCode(x)    ← auto-generated
    //   stateHolder.setPhone(x)          ← auto-generated
}

fun PhoneAuthActivity.setupComposeUI(stateHolder: PhoneAuthStateHolder) {
    setContent {
        SafarTheme(darkTheme = true) {
            PhoneAuthScreen(
                phone         = stateHolder.phone,
                countryCode   = stateHolder.countryCode,
                onPhoneChange = { stateHolder.phone = it },
                onContinue    = {
                    handleContinue(stateHolder.countryCode + stateHolder.phone.trim())
                }
            )
        }
    }
}

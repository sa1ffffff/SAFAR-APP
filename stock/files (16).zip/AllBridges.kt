// ═══════════════════════════════════════════════════════════════════════════════
// FILE 1 — SplashBridge.kt
// Package: com.safar.app.views.activities
// ═══════════════════════════════════════════════════════════════════════════════
package com.safar.app.views.activities

import androidx.activity.compose.setContent
import com.safar.app.views.ui.screens.SplashScreen
import com.safar.app.views.ui.theme.SafarTheme

fun SplashActivity.setupComposeUI() {
    setContent {
        SafarTheme(darkTheme = true) {
            SplashScreen()
        }
    }
}


// ═══════════════════════════════════════════════════════════════════════════════
// FILE 2 — SafetyBridge.kt
// Package: com.safar.app.views.activities
// ═══════════════════════════════════════════════════════════════════════════════

import androidx.compose.runtime.*
import com.safar.app.views.ui.screens.SafetyScreen

class SafetyStateHolder {
    var isChecked by mutableStateOf(false)
}

fun SafetyActivity.setupComposeUI(stateHolder: SafetyStateHolder) {
    setContent {
        SafarTheme(darkTheme = true) {
            SafetyScreen(
                isChecked       = stateHolder.isChecked,
                onCheckedChange = { stateHolder.isChecked = it },
                onIUnderstand   = { handleIUnderstand() }
            )
        }
    }
}


// ═══════════════════════════════════════════════════════════════════════════════
// FILE 3 — PhoneAuthBridge.kt
// Package: com.safar.app.views.activities
// ═══════════════════════════════════════════════════════════════════════════════

import com.safar.app.views.ui.screens.PhoneAuthScreen

class PhoneAuthStateHolder {
    var phone       by mutableStateOf("")
    var countryCode by mutableStateOf("+92")
}

fun PhoneAuthActivity.setupComposeUI(stateHolder: PhoneAuthStateHolder) {
    setContent {
        SafarTheme(darkTheme = true) {
            PhoneAuthScreen(
                phone         = stateHolder.phone,
                countryCode   = stateHolder.countryCode,
                onPhoneChange = { stateHolder.phone = it },
                onContinue    = { handleContinue(stateHolder.countryCode + stateHolder.phone.trim()) }
            )
        }
    }
}


// ═══════════════════════════════════════════════════════════════════════════════
// FILE 4 — OtpVerifyBridge.kt
// Package: com.safar.app.views.activities
// ═══════════════════════════════════════════════════════════════════════════════

import com.safar.app.views.ui.screens.OtpVerifyScreen

class OtpVerifyStateHolder {
    var otpValue      by mutableStateOf("")
    var resendSeconds by mutableStateOf(60)
    var isLoading     by mutableStateOf(false)
    var phoneNumber   by mutableStateOf("")

    fun setLoading(loading: Boolean)   { isLoading = loading }
    fun setResendSeconds(secs: Int)    { resendSeconds = secs }
    fun setPhoneNumber(phone: String)  { phoneNumber = phone }
}

fun OtpVerifyActivity.setupComposeUI(stateHolder: OtpVerifyStateHolder) {
    setContent {
        SafarTheme(darkTheme = true) {
            OtpVerifyScreen(
                phoneNumber   = stateHolder.phoneNumber,
                otpValue      = stateHolder.otpValue,
                resendSeconds = stateHolder.resendSeconds,
                isLoading     = stateHolder.isLoading,
                onOtpChange   = { stateHolder.otpValue = it },
                onVerify      = { handleVerify(stateHolder.otpValue) },
                onResend      = { handleResend() }
            )
        }
    }
}


// ═══════════════════════════════════════════════════════════════════════════════
// FILE 5 — ChatBridge.kt
// Package: com.safar.app.views.activities
// ═══════════════════════════════════════════════════════════════════════════════

import androidx.compose.runtime.mutableStateListOf
import com.safar.app.views.ui.screens.ChatMessage
import com.safar.app.views.ui.screens.ChatScreen

class ChatStateHolder {
    val messages      = mutableStateListOf<ChatMessage>()
    var isLoading     by mutableStateOf(false)

    fun addMessage(msg: ChatMessage) { messages.add(msg) }
    fun setMessages(list: List<ChatMessage>) {
        messages.clear()
        messages.addAll(list)
    }
}

fun ChatActivity.setupComposeUI(
    stateHolder   : ChatStateHolder,
    peerName      : String,
    disclaimerText: String
) {
    setContent {
        SafarTheme(darkTheme = true) {
            ChatScreen(
                peerName       = peerName,
                messages       = stateHolder.messages,
                disclaimerText = disclaimerText,
                onSend         = { text -> handleSend(text) },
                onBack         = { onBackPressed() }
            )
        }
    }
}


// ═══════════════════════════════════════════════════════════════════════════════
// FILE 6 — ProfileBridge.kt
// Package: com.safar.app.views.activities
// ═══════════════════════════════════════════════════════════════════════════════

import com.safar.app.views.ui.screens.ProfileScreen
import com.safar.app.views.ui.screens.ProfileUiState

class ProfileStateHolder {
    var state by mutableStateOf(ProfileUiState())

    fun setLoading(loading: Boolean) { state = state.copy(isLoading = loading) }
    fun setName(name: String)        { state = state.copy(name = name) }
    fun setPhone(phone: String)      { state = state.copy(phone = phone) }
    fun setTotalRides(n: Int)        { state = state.copy(totalRides = n) }
    fun setRating(r: Float, count: Int) { state = state.copy(rating = r, ratingCount = count) }
}

fun ProfileActivity.setupComposeUI(stateHolder: ProfileStateHolder) {
    setContent {
        SafarTheme(darkTheme = false) {
            ProfileScreen(
                state     = stateHolder.state,
                onMyRides = { navigateToMyRides() },
                onLogout  = { showLogoutDialog() },
                onBack    = { onBackPressed() }
            )
        }
    }
}


// ═══════════════════════════════════════════════════════════════════════════════
// FILE 7 — MyAdsBridge.kt
// Package: com.safar.app.views.activities
// ═══════════════════════════════════════════════════════════════════════════════

import com.safar.app.views.ui.screens.MyAdsScreen
import com.safar.app.views.ui.screens.MyAdsUiState
import com.safar.app.views.ui.screens.RideAdUi

class MyAdsStateHolder {
    var state by mutableStateOf(MyAdsUiState())

    fun setLoading(loading: Boolean)      { state = state.copy(isLoading = loading) }
    fun setAds(ads: List<RideAdUi>)       { state = state.copy(ads = ads, isLoading = false) }
}

fun MyAdsActivity.setupComposeUI(stateHolder: MyAdsStateHolder) {
    setContent {
        SafarTheme(darkTheme = true) {
            MyAdsScreen(
                state     = stateHolder.state,
                onAdClick = { adId -> navigateToAdDetail(adId) },
                onBack    = { onBackPressed() }
            )
        }
    }
}


// ═══════════════════════════════════════════════════════════════════════════════
// FILE 8 — PostAdBridge.kt
// Package: com.safar.app.views.activities
// ═══════════════════════════════════════════════════════════════════════════════

import com.safar.app.views.ui.screens.PostAdScreen
import com.safar.app.views.ui.screens.PostAdUiState

class PostAdStateHolder {
    var state by mutableStateOf(PostAdUiState())

    fun setLoading(loading: Boolean)          { state = state.copy(isLoading = loading) }
    fun setOrigin(address: String)            { state = state.copy(originAddress = address, originPicked = true) }
    fun setDestination(address: String)       { state = state.copy(destAddress = address, destPicked = true) }
    fun setDateTimeLabel(label: String)       { state = state.copy(dateTimeLabel = label, dateTimePicked = true) }
    fun setSeats(s: String)                   { state = state.copy(seats = s) }
    fun setVehicle(v: String)                 { state = state.copy(vehicle = v) }
    fun setNotes(n: String)                   { state = state.copy(notes = n) }
}

fun PostAdActivity.setupComposeUI(stateHolder: PostAdStateHolder) {
    setContent {
        SafarTheme(darkTheme = true) {
            PostAdScreen(
                state           = stateHolder.state,
                onSeatsChange   = { stateHolder.setSeats(it) },
                onVehicleChange = { stateHolder.setVehicle(it) },
                onNotesChange   = { stateHolder.setNotes(it) },
                onPickOrigin    = { launchOriginPicker() },
                onPickDest      = { launchDestPicker() },
                onPickDateTime  = { showDatePicker() },
                onPost          = { validateAndPost() },
                onBack          = { onBackPressed() }
            )
        }
    }
}


// ═══════════════════════════════════════════════════════════════════════════════
// FILE 9 — LocationPickerBridge.kt
// Package: com.safar.app.views.activities
// ═══════════════════════════════════════════════════════════════════════════════

import com.safar.app.views.ui.screens.LocationPickerScreen

class LocationPickerStateHolder {
    var placeName        by mutableStateOf("")
    var placeNameHint    by mutableStateOf("Move map to detect, or type a name")
    var isConfirmEnabled by mutableStateOf(false)

    // Called by Java when reverse geocode completes
    fun setPlaceName(name: String)        { placeName = name }
    fun setPlaceNameHint(hint: String)    { placeNameHint = hint }
    fun setConfirmEnabled(enabled: Boolean) { isConfirmEnabled = enabled }
}

fun LocationPickerActivity.setupComposeUI(
    stateHolder : LocationPickerStateHolder,
    title       : String
) {
    setContent {
        SafarTheme(darkTheme = true) {
            LocationPickerScreen(
                title            = title,
                placeName        = stateHolder.placeName,
                isConfirmEnabled = stateHolder.isConfirmEnabled,
                onPlaceNameChange = { stateHolder.setPlaceName(it) },
                onSearchQuery    = { query -> handleSearch(query) },
                onZoomIn         = { handleZoomIn() },
                onZoomOut        = { handleZoomOut() },
                onMyLocation     = { handleMyLocation() },
                onConfirm        = { handleConfirm(stateHolder.placeName) },
                onBack           = { onBackPressed() },
                onMapReady       = { mapView -> bindMapView(mapView) }
            )
        }
    }
}


// ═══════════════════════════════════════════════════════════════════════════════
// FILE 10 — MainBridge.kt
// Package: com.safar.app.views.activities
//
// Special case: MainActivity uses Fragments. The bridge keeps fragment logic
// intact by hosting a FragmentContainerView inside AndroidView, with a
// Material3 NavigationBar rendered in Compose at the bottom.
// ═══════════════════════════════════════════════════════════════════════════════

import android.widget.FrameLayout
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.fragment.app.FragmentContainerView
import com.safar.app.views.ui.theme.SafarDarkSurface
import com.safar.app.views.ui.theme.SafarTextSecondary
import com.safar.app.views.ui.theme.SafarYellow
import com.safar.app.R

sealed class MainTab(
    val index      : Int,
    val label      : String,
    val icon       : androidx.compose.ui.graphics.vector.ImageVector
) {
    object Map     : MainTab(0, "Map",    Icons.Rounded.Map)
    object List    : MainTab(1, "Rides",  Icons.Rounded.DirectionsCar)
    object Inbox   : MainTab(2, "Inbox",  Icons.Rounded.Inbox)
    object Profile : MainTab(3, "Profile",Icons.Rounded.Person)
}

private val mainTabs = listOf(MainTab.Map, MainTab.List, MainTab.Inbox, MainTab.Profile)

class MainStateHolder {
    var selectedTab by mutableStateOf(0)
}

fun MainActivity.setupComposeUI(
    stateHolder        : MainStateHolder,
    fragmentContainerId: Int = R.id.fragmentContainer
) {
    setContent {
        SafarTheme(darkTheme = true) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Fragment host — fills all remaining space
                Box(modifier = Modifier.weight(1f)) {
                    AndroidView(
                        factory = { ctx ->
                            FragmentContainerView(ctx).apply {
                                id = fragmentContainerId
                                layoutParams = FrameLayout.LayoutParams(
                                    FrameLayout.LayoutParams.MATCH_PARENT,
                                    FrameLayout.LayoutParams.MATCH_PARENT
                                )
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // Material3 NavigationBar
                NavigationBar(
                    containerColor = SafarDarkSurface,
                    tonalElevation = 0.dp
                ) {
                    mainTabs.forEach { tab ->
                        val selected = stateHolder.selectedTab == tab.index
                        NavigationBarItem(
                            selected = selected,
                            onClick  = { onTabSelected(tab.index) },
                            icon     = {
                                Icon(tab.icon, contentDescription = tab.label)
                            },
                            label    = {
                                Text(tab.label, style = MaterialTheme.typography.labelSmall)
                            },
                            colors   = NavigationBarItemDefaults.colors(
                                selectedIconColor   = SafarYellow,
                                selectedTextColor   = SafarYellow,
                                unselectedIconColor = SafarTextSecondary,
                                unselectedTextColor = SafarTextSecondary,
                                indicatorColor      = SafarYellow.copy(alpha = 0.15f)
                            )
                        )
                    }
                }
            }
        }
    }
}

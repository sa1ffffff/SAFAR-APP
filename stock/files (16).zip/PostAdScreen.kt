package com.safar.app.views.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.*
import com.safar.app.views.ui.theme.*

data class PostAdUiState(
    val originAddress  : String  = "",
    val destAddress    : String  = "",
    val dateTimeLabel  : String  = "",
    val seats          : String  = "",
    val vehicle        : String  = "",
    val notes          : String  = "",
    val isLoading      : Boolean = false,
    val originPicked   : Boolean = false,
    val destPicked     : Boolean = false,
    val dateTimePicked : Boolean = false
)

/**
 * WHERE TO PASTE: ui/screens/PostAdScreen.kt
 * In PostAdActivity.java → setupComposeUI(stateHolder)
 *
 * Location pickers + datetime are launched from Java — UI just displays the result.
 * [onPickOrigin]    → launches originPickerLauncher in Java
 * [onPickDest]      → launches destPickerLauncher in Java
 * [onPickDateTime]  → shows DatePickerDialog in Java
 * [onPost]          → calls validateAndPost() in Java
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostAdScreen(
    state          : PostAdUiState   = PostAdUiState(),
    onSeatsChange  : (String) -> Unit = {},
    onVehicleChange: (String) -> Unit = {},
    onNotesChange  : (String) -> Unit = {},
    onPickOrigin   : () -> Unit       = {},
    onPickDest     : () -> Unit       = {},
    onPickDateTime : () -> Unit       = {},
    onPost         : () -> Unit       = {},
    onBack         : () -> Unit       = {}
) {
    SafarTheme(darkTheme = true) {
        Scaffold(
            containerColor = SafarBlack,
            topBar = {
                TopAppBar(
                    title = {
                        Text("Post a Ride",
                            fontWeight = FontWeight.Bold,
                            color      = SafarTextPrimary)
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Rounded.ArrowBackIosNew, "Back",
                                tint = SafarTextPrimary)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = SafarDarkSurface)
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // ── Section: Route ─────────────────────────────────────────────
                SectionLabel("Route")

                // Origin picker
                LocationPickerButton(
                    label       = "From",
                    placeholder = "Tap to pick origin on map",
                    value       = state.originAddress,
                    isPicked    = state.originPicked,
                    dotColor    = Color(0xFF34C759),
                    onClick     = onPickOrigin
                )

                // Destination picker
                LocationPickerButton(
                    label       = "To",
                    placeholder = "Tap to pick destination on map",
                    value       = state.destAddress,
                    isPicked    = state.destPicked,
                    dotColor    = SafarYellow,
                    onClick     = onPickDest
                )

                Spacer(modifier = Modifier.height(4.dp))

                // ── Section: Schedule ──────────────────────────────────────────
                SectionLabel("Schedule")

                // DateTime picker
                Card(
                    shape   = RoundedCornerShape(14.dp),
                    colors  = CardDefaults.cardColors(containerColor = SafarDarkCard),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onPickDateTime() }
                ) {
                    Row(
                        modifier          = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier         = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (state.dateTimePicked) SafarYellow.copy(alpha = 0.15f)
                                    else SafarDarkSurface
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Rounded.CalendarMonth, null,
                                tint     = if (state.dateTimePicked) SafarYellow
                                           else SafarTextSecondary,
                                modifier = Modifier.size(22.dp))
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Departure Time",
                                fontSize = 11.sp,
                                color    = SafarTextSecondary)
                            Text(
                                text     = state.dateTimeLabel.ifEmpty { "Select date & time" },
                                color    = if (state.dateTimePicked) SafarTextPrimary
                                           else SafarTextSecondary,
                                fontWeight = if (state.dateTimePicked) FontWeight.SemiBold
                                             else FontWeight.Normal,
                                fontSize = 14.sp
                            )
                        }
                        Icon(Icons.Rounded.ChevronRight, null,
                            tint = SafarTextSecondary,
                            modifier = Modifier.size(18.dp))
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // ── Section: Details ───────────────────────────────────────────
                SectionLabel("Details")

                // Seats input
                DarkInputField(
                    value         = state.seats,
                    onValueChange = onSeatsChange,
                    label         = "Available Seats",
                    placeholder   = "e.g. 3",
                    icon          = Icons.Rounded.EventSeat,
                    keyboardType  = KeyboardType.Number
                )

                // Vehicle input
                DarkInputField(
                    value         = state.vehicle,
                    onValueChange = onVehicleChange,
                    label         = "Vehicle (optional)",
                    placeholder   = "e.g. Honda Civic, Silver",
                    icon          = Icons.Rounded.DirectionsCar
                )

                // Notes input
                OutlinedTextField(
                    value         = state.notes,
                    onValueChange = onNotesChange,
                    label         = { Text("Notes (optional)", color = SafarTextSecondary) },
                    placeholder   = { Text("Any additional details for riders…",
                        color = SafarTextSecondary) },
                    minLines      = 3,
                    maxLines      = 5,
                    shape         = RoundedCornerShape(14.dp),
                    colors        = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor      = SafarYellow,
                        unfocusedBorderColor    = SafarDivider,
                        focusedContainerColor   = SafarDarkCard,
                        unfocusedContainerColor = SafarDarkCard,
                        focusedTextColor        = SafarTextPrimary,
                        unfocusedTextColor      = SafarTextPrimary,
                        focusedLabelColor       = SafarYellow,
                        cursorColor             = SafarYellow
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                // ── Post Button ────────────────────────────────────────────────
                Button(
                    onClick  = onPost,
                    enabled  = !state.isLoading &&
                               state.originPicked &&
                               state.destPicked &&
                               state.dateTimePicked &&
                               state.seats.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape    = RoundedCornerShape(16.dp),
                    colors   = ButtonDefaults.buttonColors(
                        containerColor         = SafarYellow,
                        contentColor           = SafarBlack,
                        disabledContainerColor = SafarYellow.copy(alpha = 0.3f),
                        disabledContentColor   = SafarBlack.copy(alpha = 0.3f)
                    )
                ) {
                    if (state.isLoading) {
                        CircularProgressIndicator(
                            color       = SafarBlack,
                            modifier    = Modifier.size(22.dp),
                            strokeWidth = 2.5.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Posting…", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    } else {
                        Icon(Icons.Rounded.AddCircle, null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Post Ride", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

// ── Section Label ─────────────────────────────────────────────────────────────
@Composable
private fun SectionLabel(text: String) {
    Text(text,
        fontWeight    = FontWeight.Bold,
        fontSize      = 13.sp,
        color         = SafarTextSecondary,
        letterSpacing = 1.sp)
}

// ── Location Picker Button ────────────────────────────────────────────────────
@Composable
private fun LocationPickerButton(
    label      : String,
    placeholder: String,
    value      : String,
    isPicked   : Boolean,
    dotColor   : Color,
    onClick    : () -> Unit
) {
    Card(
        shape    = RoundedCornerShape(14.dp),
        colors   = CardDefaults.cardColors(containerColor = SafarDarkCard),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier          = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier
                .size(10.dp)
                .clip(androidx.compose.foundation.shape.CircleShape)
                .background(dotColor))

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(label, fontSize = 11.sp, color = SafarTextSecondary)
                Text(
                    text     = value.ifEmpty { placeholder },
                    color    = if (isPicked) SafarTextPrimary else SafarTextSecondary,
                    fontWeight = if (isPicked) FontWeight.SemiBold else FontWeight.Normal,
                    fontSize = 14.sp
                )
            }

            Icon(
                imageVector = if (isPicked) Icons.Rounded.CheckCircle
                              else Icons.Rounded.LocationOn,
                contentDescription = null,
                tint     = if (isPicked) dotColor else SafarTextSecondary,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

// ── Dark Input Field ──────────────────────────────────────────────────────────
@Composable
private fun DarkInputField(
    value        : String,
    onValueChange: (String) -> Unit,
    label        : String,
    placeholder  : String,
    icon         : androidx.compose.ui.graphics.vector.ImageVector,
    keyboardType : KeyboardType = KeyboardType.Text
) {
    OutlinedTextField(
        value         = value,
        onValueChange = onValueChange,
        label         = { Text(label, color = SafarTextSecondary) },
        placeholder   = { Text(placeholder, color = SafarTextSecondary.copy(alpha = 0.6f)) },
        leadingIcon   = {
            Icon(icon, null, tint = SafarTextSecondary, modifier = Modifier.size(20.dp))
        },
        singleLine    = true,
        shape         = RoundedCornerShape(14.dp),
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        colors        = OutlinedTextFieldDefaults.colors(
            focusedBorderColor      = SafarYellow,
            unfocusedBorderColor    = SafarDivider,
            focusedContainerColor   = SafarDarkCard,
            unfocusedContainerColor = SafarDarkCard,
            focusedTextColor        = SafarTextPrimary,
            unfocusedTextColor      = SafarTextPrimary,
            focusedLabelColor       = SafarYellow,
            cursorColor             = SafarYellow
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

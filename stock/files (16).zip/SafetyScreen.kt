package com.safar.app.views.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.safar.app.views.ui.theme.*

data class SafetyGuidelineItem(
    val icon  : ImageVector,
    val title : String,
    val body  : String
)

private val guidelines = listOf(
    SafetyGuidelineItem(Icons.Rounded.VerifiedUser,    "Verified Community", "All users are verified via phone or Google. Share rides only with people in your network."),
    SafetyGuidelineItem(Icons.Rounded.Chat,            "Communicate Clearly", "Use the in-app chat to coordinate. Never share personal financial details."),
    SafetyGuidelineItem(Icons.Rounded.ReportProblem,   "Report Issues",       "Use the report button if you feel unsafe. Our team reviews all reports within 24 hours."),
    SafetyGuidelineItem(Icons.Rounded.Groups,          "Respect Others",      "Treat fellow riders with respect. Harassment of any kind will result in account removal."),
    SafetyGuidelineItem(Icons.Rounded.LocationOn,      "Share Your Route",    "Let someone you trust know your travel plans when carpooling with new people.")
)

/**
 * WHERE TO PASTE: ui/screens/SafetyScreen.kt
 * In SafetyActivity.java → setupComposeUI(stateHolder)
 */
@Composable
fun SafetyScreen(
    isChecked       : Boolean = false,
    onCheckedChange : (Boolean) -> Unit = {},
    onIUnderstand   : () -> Unit        = {}
) {
    SafarTheme(darkTheme = true) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(SafarBlack)
        ) {
            // ── Header ────────────────────────────────────────────────────────
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SafarDarkSurface)
                    .padding(horizontal = 24.dp, vertical = 32.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally,
                       modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(SafarYellow.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Shield, null,
                            tint = SafarYellow, modifier = Modifier.size(36.dp))
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Community Safety",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize   = 24.sp,
                        color      = SafarTextPrimary)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Please read before your first ride",
                        fontSize = 13.sp,
                        color    = SafarTextSecondary)
                }
            }

            // ── Guidelines list ───────────────────────────────────────────────
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                guidelines.forEach { item ->
                    SafetyGuidelineCard(item = item)
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // ── Bottom section ────────────────────────────────────────────────
            Surface(
                color = SafarDarkSurface,
                tonalElevation = 4.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 16.dp)
                        .navigationBarsPadding()
                ) {
                    // Checkbox row
                    Row(
                        modifier          = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(SafarDarkCard)
                            .clickable { onCheckedChange(!isChecked) }
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked         = isChecked,
                            onCheckedChange = onCheckedChange,
                            colors          = CheckboxDefaults.colors(
                                checkedColor         = SafarYellow,
                                checkmarkColor       = SafarBlack,
                                uncheckedColor       = SafarTextSecondary
                            )
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text     = "I understand and agree to the community safety guidelines",
                            color    = SafarTextPrimary,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick  = onIUnderstand,
                        enabled  = isChecked,
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        shape    = RoundedCornerShape(14.dp),
                        colors   = ButtonDefaults.buttonColors(
                            containerColor         = SafarYellow,
                            contentColor           = SafarBlack,
                            disabledContainerColor = SafarYellow.copy(alpha = 0.35f),
                            disabledContentColor   = SafarBlack.copy(alpha = 0.35f)
                        )
                    ) {
                        Text("I Understand — Let's Ride 🚗",
                            fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SafetyGuidelineCard(item: SafetyGuidelineItem) {
    Card(
        shape  = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SafarDarkCard)
    ) {
        Row(
            modifier          = Modifier.padding(16.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier         = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(SafarYellow.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(item.icon, null, tint = SafarYellow, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(item.title, fontWeight = FontWeight.Bold,
                    fontSize = 14.sp, color = SafarTextPrimary)
                Spacer(modifier = Modifier.height(4.dp))
                Text(item.body, fontSize = 13.sp,
                    color = SafarTextSecondary, lineHeight = 18.sp)
            }
        }
    }
}

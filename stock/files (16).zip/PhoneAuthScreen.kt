package com.safar.app.views.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.safar.app.views.ui.theme.*

/**
 * WHERE TO PASTE: ui/screens/PhoneAuthScreen.kt
 * In PhoneAuthActivity.java → setupComposeUI(stateHolder)
 */
@Composable
fun PhoneAuthScreen(
    phone         : String  = "",
    countryCode   : String  = "+92",
    onPhoneChange : (String) -> Unit = {},
    onContinue    : () -> Unit       = {}
) {
    SafarTheme(darkTheme = true) {
        Column(
            modifier            = Modifier
                .fillMaxSize()
                .background(SafarBlack)
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(80.dp))

            // Icon
            Box(
                modifier         = Modifier
                    .size(80.dp)
                    .background(SafarYellow.copy(alpha = 0.12f),
                        RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Phone, null,
                    tint     = SafarYellow,
                    modifier = Modifier.size(40.dp))
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text("Enter Your Phone",
                fontWeight = FontWeight.ExtraBold,
                fontSize   = 28.sp,
                color      = SafarTextPrimary)

            Spacer(modifier = Modifier.height(8.dp))

            Text("We'll send you a verification code",
                fontSize  = 14.sp,
                color     = SafarTextSecondary,
                textAlign = TextAlign.Center)

            Spacer(modifier = Modifier.height(40.dp))

            // Phone input
            Row(
                modifier          = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .background(SafarDarkCard, RoundedCornerShape(16.dp))
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Country code chip (wire to CountryCodePicker via AndroidView)
                Box(
                    modifier = Modifier
                        .background(SafarDarkSurface, RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(countryCode,
                        color      = SafarYellow,
                        fontWeight = FontWeight.Bold,
                        fontSize   = 15.sp)
                }

                Spacer(modifier = Modifier.width(4.dp))

                OutlinedTextField(
                    value         = phone,
                    onValueChange = onPhoneChange,
                    placeholder   = {
                        Text("3XX-XXXXXXX", color = SafarTextSecondary)
                    },
                    singleLine    = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    colors        = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor      = SafarYellow.copy(alpha = 0f),
                        unfocusedBorderColor    = SafarYellow.copy(alpha = 0f),
                        focusedContainerColor   = SafarYellow.copy(alpha = 0f),
                        unfocusedContainerColor = SafarYellow.copy(alpha = 0f),
                        focusedTextColor        = SafarTextPrimary,
                        unfocusedTextColor      = SafarTextPrimary,
                        cursorColor             = SafarYellow
                    ),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick  = onContinue,
                enabled  = phone.length >= 7,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape    = RoundedCornerShape(16.dp),
                colors   = ButtonDefaults.buttonColors(
                    containerColor         = SafarYellow,
                    contentColor           = SafarBlack,
                    disabledContainerColor = SafarYellow.copy(alpha = 0.35f),
                    disabledContentColor   = SafarBlack.copy(alpha = 0.35f)
                )
            ) {
                Text("Continue", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Icon(Icons.Rounded.ArrowForward, null, modifier = Modifier.size(18.dp))
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text("Standard SMS rates may apply",
                fontSize = 11.sp,
                color    = SafarTextSecondary.copy(alpha = 0.6f))
        }
    }
}

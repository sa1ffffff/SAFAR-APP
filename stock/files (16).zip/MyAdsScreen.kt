package com.safar.app.views.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.safar.app.views.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

// Mirrors your RideAd model — use just the fields needed for display
data class RideAdUi(
    val adId          : String,
    val origin        : String,
    val destination   : String,
    val departureTime : Long,
    val seats         : Int,
    val vehicle       : String,
    val status        : String = "Open"   // "Open" | "Filled"
)

data class MyAdsUiState(
    val ads       : List<RideAdUi> = emptyList(),
    val isLoading : Boolean        = false
)

/**
 * WHERE TO PASTE: ui/screens/MyAdsScreen.kt
 * In MyAdsActivity.java → setupComposeUI(stateHolder)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyAdsScreen(
    state    : MyAdsUiState         = MyAdsUiState(),
    onAdClick: (String) -> Unit     = {},
    onBack   : () -> Unit           = {}
) {
    SafarTheme(darkTheme = true) {
        Scaffold(
            containerColor = SafarBlack,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("My Rides",
                                fontWeight = FontWeight.Bold,
                                color      = SafarTextPrimary,
                                fontSize   = 18.sp)
                            Text("${state.ads.size} total",
                                fontSize = 12.sp,
                                color    = SafarTextSecondary)
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Rounded.ArrowBackIosNew, "Back",
                                tint = SafarTextPrimary)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = SafarDarkSurface)
                )
            }
        ) { padding ->
            when {
                state.isLoading -> {
                    Box(
                        Modifier.fillMaxSize().padding(padding),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = SafarYellow)
                    }
                }
                state.ads.isEmpty() -> {
                    EmptyAdsView(modifier = Modifier.fillMaxSize().padding(padding))
                }
                else -> {
                    LazyColumn(
                        modifier       = Modifier
                            .fillMaxSize()
                            .padding(padding),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(state.ads, key = { it.adId }) { ad ->
                            RideAdCard(ad = ad, onClick = { onAdClick(ad.adId) })
                        }
                        item { Spacer(modifier = Modifier.height(16.dp)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun RideAdCard(ad: RideAdUi, onClick: () -> Unit) {
    val sdf   = remember { SimpleDateFormat("EEE, dd MMM • hh:mm a", Locale.getDefault()) }
    val isOpen = ad.status.equals("Open", ignoreCase = true)

    Card(
        shape     = RoundedCornerShape(16.dp),
        colors    = CardDefaults.cardColors(containerColor = SafarDarkCard),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier  = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(16.dp)) {

            // Status chip
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (isOpen) StatusOpen.copy(alpha = 0.15f)
                            else StatusFilled.copy(alpha = 0.15f)
                        )
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(ad.status,
                        color      = if (isOpen) StatusOpen else StatusFilled,
                        fontSize   = 11.sp,
                        fontWeight = FontWeight.Bold)
                }
                Icon(Icons.Rounded.ChevronRight, null,
                    tint     = SafarTextSecondary,
                    modifier = Modifier.size(20.dp))
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Route
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(8.dp).clip(CircleShape)
                    .background(Color(0xFF34C759)))
                Spacer(modifier = Modifier.width(10.dp))
                Text(ad.origin,
                    fontWeight = FontWeight.SemiBold,
                    fontSize   = 15.sp,
                    color      = SafarTextPrimary,
                    modifier   = Modifier.weight(1f))
            }

            Box(modifier = Modifier
                .padding(start = 3.dp, top = 4.dp, bottom = 4.dp)
                .width(2.dp).height(16.dp)
                .background(SafarDivider))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(8.dp).clip(CircleShape)
                    .background(SafarYellow))
                Spacer(modifier = Modifier.width(10.dp))
                Text(ad.destination,
                    fontWeight = FontWeight.SemiBold,
                    fontSize   = 15.sp,
                    color      = SafarTextPrimary,
                    modifier   = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = SafarDivider)
            Spacer(modifier = Modifier.height(10.dp))

            // Meta info row
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                InfoPill(Icons.Rounded.Schedule,
                    sdf.format(Date(ad.departureTime)))
                InfoPill(Icons.Rounded.EventSeat, "${ad.seats} seats")
            }
        }
    }
}

@Composable
private fun InfoPill(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = SafarYellowDark,
            modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(text, fontSize = 12.sp, color = SafarTextSecondary)
    }
}

@Composable
private fun EmptyAdsView(modifier: Modifier = Modifier) {
    Column(
        modifier            = modifier,
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Rounded.DirectionsCar, null,
            tint     = SafarTextSecondary.copy(alpha = 0.3f),
            modifier = Modifier.size(72.dp))
        Spacer(modifier = Modifier.height(16.dp))
        Text("No rides posted yet",
            fontWeight = FontWeight.Bold,
            fontSize   = 18.sp,
            color      = SafarTextSecondary)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Your posted rides will appear here",
            fontSize = 14.sp,
            color    = SafarTextSecondary.copy(alpha = 0.6f))
    }
}

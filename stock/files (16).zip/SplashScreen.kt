package com.safar.app.views.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.safar.app.views.ui.theme.SafarBlack
import com.safar.app.views.ui.theme.SafarTextSecondary
import com.safar.app.views.ui.theme.SafarYellow

/**
 * WHERE TO PASTE: ui/screens/SplashScreen.kt
 * Animated splash — logo scales in, tagline fades in.
 * Routing logic stays in SplashActivity.java (unchanged).
 */
@Composable
fun SplashScreen() {
    val scale = remember { Animatable(0.6f) }
    val alpha = remember { Animatable(0f) }
    val taglineAlpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        // Logo pops in
        scale.animateTo(1f, animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness    = Spring.StiffnessLow
        ))
        // Fade in simultaneously
        alpha.animateTo(1f, animationSpec = tween(400))
        // Tagline fades in after logo settles
        taglineAlpha.animateTo(1f, animationSpec = tween(500, delayMillis = 200))
    }

    Box(
        modifier         = Modifier
            .fillMaxSize()
            .background(SafarBlack),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector        = Icons.Rounded.DirectionsCar,
                contentDescription = "Safar",
                tint               = SafarYellow,
                modifier           = Modifier
                    .size(64.dp)
                    .scale(scale.value)
                    .alpha(alpha.value)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text       = "SAFAR",
                fontSize   = 48.sp,
                fontWeight = FontWeight.ExtraBold,
                color      = SafarYellow,
                letterSpacing = 6.sp,
                modifier   = Modifier
                    .scale(scale.value)
                    .alpha(alpha.value)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text     = "Community Carpool, Made Easy",
                fontSize = 13.sp,
                color    = SafarTextSecondary,
                modifier = Modifier.alpha(taglineAlpha.value)
            )
        }

        // Version text at bottom
        Text(
            text     = "v1.0",
            fontSize = 11.sp,
            color    = SafarTextSecondary.copy(alpha = 0.4f),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 32.dp)
                .alpha(taglineAlpha.value)
        )
    }
}

package com.safar.app.views.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.safar.app.views.ui.theme.*

data class ProfileUiState(
    val name        : String = "",
    val phone       : String = "",
    val totalRides  : Int    = 0,
    val rating      : Float  = 0f,
    val ratingCount : Int    = 0,
    val isLoading   : Boolean = false
)

/**
 * WHERE TO PASTE: ui/screens/ProfileScreen.kt
 * In ProfileActivity.java → setupComposeUI(stateHolder)
 * Uses LIGHT theme to match your original activity_profile.xml
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    state        : ProfileUiState = ProfileUiState(),
    onMyRides    : () -> Unit     = {},
    onLogout     : () -> Unit     = {},
    onBack       : () -> Unit     = {}
) {
    SafarTheme(darkTheme = false) {
        Scaffold(
            containerColor = SafarBg,
            topBar = {
                TopAppBar(
                    title = { Text("Profile", fontWeight = FontWeight.Bold, color = SafarTextDark) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Rounded.ArrowBackIosNew, "Back", tint = SafarTextDark)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = SafarWhite)
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
            ) {
                // ── Avatar + Name Card ─────────────────────────────────────────
                Card(
                    shape     = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp),
                    colors    = CardDefaults.cardColors(containerColor = SafarWhite),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier  = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier            = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Avatar circle with initials
                        Box(
                            modifier         = Modifier
                                .size(88.dp)
                                .clip(CircleShape)
                                .background(SafarYellowDark.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text       = state.name.firstOrNull()?.uppercaseChar()?.toString() ?: "?",
                                fontSize   = 36.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color      = SafarYellowDark
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        if (state.isLoading) {
                            CircularProgressIndicator(
                                color     = SafarYellowDark,
                                modifier  = Modifier.size(24.dp),
                                strokeWidth = 2.5.dp
                            )
                        } else {
                            Text(state.name,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize   = 22.sp,
                                color      = SafarTextDark)

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(state.phone,
                                fontSize = 14.sp,
                                color    = SafarTextMuted)
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Stats row
                        Row(
                            modifier              = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            StatChip(
                                value = "${state.totalRides}",
                                label = "Rides"
                            )
                            // Divider
                            Box(modifier = Modifier
                                .width(1.dp)
                                .height(40.dp)
                                .background(SafarDividerLight))
                            StatChip(
                                value = if (state.ratingCount > 0)
                                    String.format("%.1f", state.rating) else "—",
                                label = if (state.ratingCount > 0)
                                    "${state.ratingCount} reviews" else "No reviews"
                            )
                            if (state.ratingCount > 0) {
                                Box(modifier = Modifier
                                    .width(1.dp)
                                    .height(40.dp)
                                    .background(SafarDividerLight))
                                // Star rating
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Row {
                                        repeat(5) { i ->
                                            Icon(
                                                imageVector = if (i < state.rating.toInt())
                                                    Icons.Rounded.Star else Icons.Rounded.StarBorder,
                                                contentDescription = null,
                                                tint     = SafarYellowDark,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                    Text("Rating", fontSize = 11.sp, color = SafarTextMuted)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // ── Action Cards ──────────────────────────────────────────────
                Column(
                    modifier            = Modifier.padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ProfileActionCard(
                        icon     = Icons.Rounded.DirectionsCar,
                        title    = "My Rides",
                        subtitle = "View all your posted rides",
                        onClick  = onMyRides
                    )
                    ProfileActionCard(
                        icon     = Icons.Rounded.Help,
                        title    = "Help & Support",
                        subtitle = "FAQs and contact support",
                        onClick  = {}
                    )
                    ProfileActionCard(
                        icon     = Icons.Rounded.Policy,
                        title    = "Privacy Policy",
                        subtitle = "How we handle your data",
                        onClick  = {}
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Logout button
                    OutlinedButton(
                        onClick  = onLogout,
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape    = RoundedCornerShape(14.dp),
                        border   = BorderStroke(1.dp, Color(0xFFFF3B30).copy(alpha = 0.5f)),
                        colors   = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color(0xFFFF3B30)
                        )
                    ) {
                        Icon(Icons.Rounded.Logout, null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Logout", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    }

                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }
}

@Composable
private fun StatChip(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = SafarTextDark)
        Text(label, fontSize = 11.sp, color = SafarTextMuted)
    }
}

@Composable
private fun ProfileActionCard(
    icon    : androidx.compose.ui.graphics.vector.ImageVector,
    title   : String,
    subtitle: String,
    onClick : () -> Unit
) {
    Card(
        shape     = RoundedCornerShape(14.dp),
        colors    = CardDefaults.cardColors(containerColor = SafarWhite),
        elevation = CardDefaults.cardElevation(1.dp),
        modifier  = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier          = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier         = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(SafarYellowDark.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, tint = SafarYellowDark, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp, color = SafarTextDark)
                Text(subtitle, fontSize = 12.sp, color = SafarTextMuted)
            }
            Icon(Icons.Rounded.ChevronRight, null,
                tint = SafarTextMuted, modifier = Modifier.size(20.dp))
        }
    }
}

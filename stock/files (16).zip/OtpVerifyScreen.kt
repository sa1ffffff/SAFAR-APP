package com.safar.app.views.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.safar.app.views.ui.theme.*

/**
 * WHERE TO PASTE: ui/screens/OtpVerifyScreen.kt
 * In OtpVerifyActivity.java → setupComposeUI(stateHolder)
 *
 * [phoneNumber]    — displayed hint, e.g. "+92 3XX XXXXXXX"
 * [otpValue]       — current OTP digits
 * [resendSeconds]  — countdown; 0 means resend is available
 * [isLoading]      — show progress indicator
 */
@Composable
fun OtpVerifyScreen(
    phoneNumber   : String  = "",
    otpValue      : String  = "",
    resendSeconds : Int     = 60,
    isLoading     : Boolean = false,
    onOtpChange   : (String) -> Unit = {},
    onVerify      : () -> Unit       = {},
    onResend      : () -> Unit       = {}
) {
    SafarTheme(darkTheme = true) {
        Column(
            modifier            = Modifier
                .fillMaxSize()
                .background(SafarBlack)
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(72.dp))

            // Icon
            Box(
                modifier         = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(SafarYellow.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Sms, null,
                    tint     = SafarYellow,
                    modifier = Modifier.size(40.dp))
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text("Verify Your Number",
                fontWeight = FontWeight.ExtraBold,
                fontSize   = 28.sp,
                color      = SafarTextPrimary)

            Spacer(modifier = Modifier.height(8.dp))

            Text("Code sent to $phoneNumber",
                fontSize  = 14.sp,
                color     = SafarTextSecondary,
                textAlign = TextAlign.Center)

            Spacer(modifier = Modifier.height(40.dp))

            // OTP input field
            OutlinedTextField(
                value         = otpValue,
                onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) onOtpChange(it) },
                placeholder   = { Text("• • • • • •", color = SafarTextSecondary,
                    fontSize = 22.sp, letterSpacing = 8.sp) },
                singleLine    = true,
                textStyle     = LocalTextStyle.current.copy(
                    fontSize      = 28.sp,
                    fontWeight    = FontWeight.Bold,
                    textAlign     = TextAlign.Center,
                    letterSpacing = 10.sp,
                    color         = SafarTextPrimary
                ),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                shape  = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor      = SafarYellow,
                    unfocusedBorderColor    = SafarDivider,
                    focusedContainerColor   = SafarDarkCard,
                    unfocusedContainerColor = SafarDarkCard,
                    cursorColor             = SafarYellow
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(72.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Verify button
            Button(
                onClick  = onVerify,
                enabled  = otpValue.length == 6 && !isLoading,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape    = RoundedCornerShape(16.dp),
                colors   = ButtonDefaults.buttonColors(
                    containerColor         = SafarYellow,
                    contentColor           = SafarBlack,
                    disabledContainerColor = SafarYellow.copy(alpha = 0.35f),
                    disabledContentColor   = SafarBlack.copy(alpha = 0.35f)
                )
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        color       = SafarBlack,
                        modifier    = Modifier.size(22.dp),
                        strokeWidth = 2.5.dp
                    )
                } else {
                    Icon(Icons.Rounded.CheckCircle, null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Verify Code", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Resend
            AnimatedContent(
                targetState = resendSeconds > 0,
                label       = "resend"
            ) { counting ->
                if (counting) {
                    Text(
                        "Resend code in ${resendSeconds}s",
                        color    = SafarTextSecondary,
                        fontSize = 13.sp
                    )
                } else {
                    Text(
                        "Resend OTP",
                        color    = SafarYellow,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable { onResend() }
                    )
                }
            }
        }
    }
}

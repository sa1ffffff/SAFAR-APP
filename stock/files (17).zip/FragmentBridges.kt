package com.safar.app.views.fragments

// ═══════════════════════════════════════════════════════════════════════════════
// HOW FRAGMENTS WORK DIFFERENTLY FROM ACTIVITIES
// ───────────────────────────────────────────────────────────────────────────────
// Activities use:   setContent { }
// Fragments use:    return ComposeView(requireContext()).apply { setContent { } }
//
// No separate bridge file needed for fragments.
// The change happens directly in each Fragment's onCreateView().
// ═══════════════════════════════════════════════════════════════════════════════

// ───────────────────────────────────────────────────────────────────────────────
// MapFragment.java  — onCreateView changes
// ───────────────────────────────────────────────────────────────────────────────
//
// BEFORE:
//   @Override public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saved) {
//       return inflater.inflate(R.layout.fragment_map, container, false);
//   }
//
// AFTER:
//   @Override public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saved) {
//       return new ComposeView(requireContext()) {{
//           setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed);
//           setContent(new AbstractComposeView.Content() {
//               // Use Kotlin companion or just override via Kotlin file (see MapFragmentBridge.kt)
//           });
//       }};
//   }
//
// CLEANEST APPROACH (recommended): Convert MapFragment.java → MapFragment.kt
// This avoids the Java/Compose interop verbosity:
//
//   class MapFragment : Fragment() {
//       override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) =
//           ComposeView(requireContext()).apply {
//               setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
//               setContent {
//                   SafarTheme(darkTheme = true) {
//                       MapScreen(
//                           onMapReady   = { mapView -> /* store ref, call mapView.getMapAsync(this@MapFragment) */ },
//                           onPostRide   = { startActivity(Intent(requireContext(), PostAdActivity::class.java)) },
//                           onSearchRide = { /* show search bottom sheet or filter */ }
//                       )
//                   }
//               }
//           }
//
//       // All map logic (onMapReady, geocoder, etc.) stays here in Kotlin
//   }
// ───────────────────────────────────────────────────────────────────────────────


// ───────────────────────────────────────────────────────────────────────────────
// ListFragment.java  — onCreateView changes
// ───────────────────────────────────────────────────────────────────────────────
//
// Convert to ListFragment.kt:
//
//   class ListFragment : Fragment() {
//       private val stateHolder = RidesListStateHolder()
//
//       override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) =
//           ComposeView(requireContext()).apply {
//               setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
//               setContent {
//                   SafarTheme(darkTheme = true) {
//                       RidesListScreen(
//                           state          = stateHolder.state,
//                           onRideClick    = { adId ->
//                               val i = Intent(requireContext(), AdDetailActivity::class.java)
//                               i.putExtra(AppConstants.KEY_AD_ID, adId)
//                               startActivity(i)
//                           },
//                           onSearchChange = { stateHolder.setSearchQuery(it) }
//                       )
//                   }
//               }
//           }
//
//       override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
//           super.onViewCreated(view, savedInstanceState)
//           loadRides()   // your existing Firebase load logic
//       }
//
//       private fun loadRides() {
//           stateHolder.setLoading(true)
//           // Firebase query → convert results to RideAdListItem → stateHolder.setRides(list)
//       }
//   }
// ───────────────────────────────────────────────────────────────────────────────


// ───────────────────────────────────────────────────────────────────────────────
// InboxFragment.java  — onCreateView changes
// ───────────────────────────────────────────────────────────────────────────────
//
// Convert to InboxFragment.kt:
//
//   class InboxFragment : Fragment() {
//       private val stateHolder = InboxStateHolder()
//
//       override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) =
//           ComposeView(requireContext()).apply {
//               setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
//               setContent {
//                   SafarTheme(darkTheme = true) {
//                       InboxScreen(
//                           state         = stateHolder.state,
//                           onChatOpen    = { chatRoomId, peerName ->
//                               val i = Intent(requireContext(), ChatActivity::class.java)
//                               i.putExtra(AppConstants.KEY_CHAT_ROOM_ID, chatRoomId)
//                               i.putExtra(AppConstants.KEY_OTHER_USER_NAME, peerName)
//                               startActivity(i)
//                           },
//                           onRequestOpen = { adId ->
//                               val i = Intent(requireContext(), AdDetailActivity::class.java)
//                               i.putExtra(AppConstants.KEY_AD_ID, adId)
//                               startActivity(i)
//                           }
//                       )
//                   }
//               }
//           }
//
//       override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
//           super.onViewCreated(view, savedInstanceState)
//           loadInbox()
//       }
//
//       private fun loadInbox() {
//           stateHolder.setLoading(true)
//           // Firebase query → convert to InboxItem list → stateHolder.setItems(list)
//       }
//   }
// ───────────────────────────────────────────────────────────────────────────────

// State holders for fragments (put these in same file as the fragment, or separate files)

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.safar.app.views.ui.screens.InboxItem
import com.safar.app.views.ui.screens.InboxUiState
import com.safar.app.views.ui.screens.RideAdListItem
import com.safar.app.views.ui.screens.RidesListUiState

class RidesListStateHolder {
    var state by mutableStateOf(RidesListUiState())
        private set

    fun setLoading(loading: Boolean)        { state = state.copy(isLoading = loading) }
    fun setRides(rides: List<RideAdListItem>) { state = state.copy(rides = rides, isLoading = false) }
    fun setSearchQuery(q: String)           { state = state.copy(searchQuery = q) }
}

class InboxStateHolder {
    var state by mutableStateOf(InboxUiState())
        private set

    fun setLoading(loading: Boolean)      { state = state.copy(isLoading = loading) }
    fun setItems(items: List<InboxItem>)  { state = state.copy(items = items, isLoading = false) }
}

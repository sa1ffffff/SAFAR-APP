package com.safar.app.views.activities

import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.safar.app.views.ui.screens.PostAdScreen
import com.safar.app.views.ui.screens.PostAdUiState
import com.safar.app.views.ui.theme.SafarTheme

/**
 * WHERE TO PASTE: views/activities/PostAdBridge.kt
 *
 * In PostAdActivity.java:
 *   REMOVE: binding field, inflate, setContentView
 *   REMOVE: binding.etOrigin.setOnClickListener, btnPickOrigin, btnPickDestination,
 *           btnPickDateTime, btnPost
 *   ADD field:    private PostAdStateHolder stateHolder;
 *   ADD onCreate: stateHolder = new PostAdStateHolder();
 *                 PostAdBridgeKt.setupComposeUI(this, stateHolder);
 *
 *   CHANGE originPickerLauncher result: stateHolder.setOrigin(addr)  (was binding.etOrigin.setText)
 *   CHANGE destPickerLauncher result:   stateHolder.setDestination(addr)
 *   CHANGE updateDateTimeDisplay():     stateHolder.setDateTimeLabel(formattedDate)
 *   CHANGE validateAndPost():           read from stateHolder.getState() instead of binding.etXxx
 *   CHANGE onLoading():                 stateHolder.setLoading(isLoading)
 *
 *   ADD methods:
 *     public void launchOriginPicker() { originPickerLauncher.launch(...) }
 *     public void launchDestPicker()   { destPickerLauncher.launch(...) }
 *     public void showDatePicker()     { DatePickerDialog ... (same logic, unchanged) }
 */
class PostAdStateHolder {
    var state by mutableStateOf(PostAdUiState())
        private set

    fun setLoading(loading: Boolean)    { state = state.copy(isLoading = loading) }
    fun setOrigin(address: String)      { state = state.copy(originAddress = address, originPicked = true) }
    fun setDestination(address: String) { state = state.copy(destAddress = address, destPicked = true) }
    fun setDateTimeLabel(label: String) { state = state.copy(dateTimeLabel = label, dateTimePicked = true) }
    fun setSeats(s: String)             { state = state.copy(seats = s) }
    fun setVehicle(v: String)           { state = state.copy(vehicle = v) }
    fun setNotes(n: String)             { state = state.copy(notes = n) }
    fun getState(): PostAdUiState       = state
}

fun PostAdActivity.setupComposeUI(stateHolder: PostAdStateHolder) {
    setContent {
        SafarTheme(darkTheme = true) {
            PostAdScreen(
                state           = stateHolder.state,
                onSeatsChange   = { stateHolder.setSeats(it) },
                onVehicleChange = { stateHolder.setVehicle(it) },
                onNotesChange   = { stateHolder.setNotes(it) },
                onPickOrigin    = { launchOriginPicker() },
                onPickDest      = { launchDestPicker() },
                onPickDateTime  = { showDatePicker() },
                onPost          = { validateAndPost() },
                onBack          = { onBackPressed() }
            )
        }
    }
}

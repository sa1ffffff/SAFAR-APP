package com.safar.app.views.activities

import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.safar.app.views.ui.screens.OtpVerifyScreen
import com.safar.app.views.ui.theme.SafarTheme

/**
 * WHERE TO PASTE: views/activities/OtpVerifyBridge.kt
 *
 * In OtpVerifyActivity.java:
 *   REMOVE: binding field, inflate, setContentView, btnVerify + tvResend listeners
 *   ADD field:    private OtpVerifyStateHolder stateHolder;
 *   ADD onCreate: stateHolder = new OtpVerifyStateHolder();
 *                 stateHolder.setPhoneNumber(phoneNumber != null ? phoneNumber : "");
 *                 OtpVerifyBridgeKt.setupComposeUI(this, stateHolder);
 *
 *   CHANGE setLoading():
 *     was: binding.progressBar.setVisibility(...); binding.btnVerify.setEnabled(...)
 *     now: stateHolder.setLoading(loading);
 *
 *   CHANGE startResendTimer():
 *     was: binding.tvResend.setText("Resend in Xs") and setEnabled
 *     now: stateHolder.setResendSeconds((int)(ms / 1000)) and stateHolder.setResendSeconds(0)
 *
 *   ADD methods:
 *     public void handleVerify(String code) { verifyCode(code); }
 *     public void handleResend() { sendOtp(phoneNumber, true); }
 */
class OtpVerifyStateHolder {
    var otpValue      by mutableStateOf("")
    var resendSeconds by mutableStateOf(60)
    var isLoading     by mutableStateOf(false)
    var phoneNumber   by mutableStateOf("")

    fun setLoading(loading: Boolean)      { isLoading = loading }
    fun setResendSeconds(secs: Int)       { resendSeconds = secs }
    fun setPhoneNumber(phone: String)     { phoneNumber = phone }
    fun getOtpValue(): String             = otpValue
}

fun OtpVerifyActivity.setupComposeUI(stateHolder: OtpVerifyStateHolder) {
    setContent {
        SafarTheme(darkTheme = true) {
            OtpVerifyScreen(
                phoneNumber   = stateHolder.phoneNumber,
                otpValue      = stateHolder.otpValue,
                resendSeconds = stateHolder.resendSeconds,
                isLoading     = stateHolder.isLoading,
                onOtpChange   = { stateHolder.otpValue = it },
                onVerify      = { handleVerify(stateHolder.otpValue) },
                onResend      = { handleResend() }
            )
        }
    }
}

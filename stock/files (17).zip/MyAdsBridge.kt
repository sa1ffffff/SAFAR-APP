package com.safar.app.views.activities

import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.safar.app.views.ui.screens.MyAdsScreen
import com.safar.app.views.ui.screens.MyAdsUiState
import com.safar.app.views.ui.screens.RideAdUi
import com.safar.app.views.ui.theme.SafarTheme

/**
 * WHERE TO PASTE: views/activities/MyAdsBridge.kt
 *
 * In MyAdsActivity.java:
 *   REMOVE: binding field, inflate, setContentView
 *   REMOVE: adapter + RecyclerView setup
 *   ADD field:    private MyAdsStateHolder stateHolder;
 *   ADD onCreate: stateHolder = new MyAdsStateHolder();
 *                 MyAdsBridgeKt.setupComposeUI(this, stateHolder);
 *
 *   CHANGE onAdsLoaded(): convert List<RideAd> → List<RideAdUi> → stateHolder.setAds(uiList)
 *   CHANGE onLoading():   stateHolder.setLoading(isLoading)
 *   ADD:   public void navigateToAdDetail(String adId) { ... startActivity AdDetailActivity ... }
 */
class MyAdsStateHolder {
    var state by mutableStateOf(MyAdsUiState())
        private set

    fun setLoading(loading: Boolean)    { state = state.copy(isLoading = loading) }
    fun setAds(ads: List<RideAdUi>)     { state = state.copy(ads = ads, isLoading = false) }
}

fun MyAdsActivity.setupComposeUI(stateHolder: MyAdsStateHolder) {
    setContent {
        SafarTheme(darkTheme = true) {
            MyAdsScreen(
                state     = stateHolder.state,
                onAdClick = { adId -> navigateToAdDetail(adId) },
                onBack    = { onBackPressed() }
            )
        }
    }
}

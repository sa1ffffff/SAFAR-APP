package com.safar.app.views.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import com.safar.app.views.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

// ── UI model for a ride ad item in the list ───────────────────────────────────
data class RideAdListItem(
    val adId          : String,
    val origin        : String,
    val destination   : String,
    val departureTime : Long,
    val seats         : Int,
    val postedBy      : String,
    val vehicle       : String = "",
    val status        : String = "Open"
)

data class RidesListUiState(
    val rides     : List<RideAdListItem> = emptyList(),
    val isLoading : Boolean              = false,
    val searchQuery: String             = ""
)

/**
 * WHERE TO PASTE: ui/screens/RidesListScreen.kt
 * Used by ListFragment.java — replace onCreateView with ComposeView.
 *
 * [onRideClick]  → open AdDetailActivity with adId
 * [onFilterTap]  → show filter bottom sheet (optional future feature)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RidesListScreen(
    state         : RidesListUiState  = RidesListUiState(),
    onRideClick   : (String) -> Unit  = {},
    onSearchChange: (String) -> Unit  = {},
    onFilterTap   : () -> Unit        = {}
) {
    SafarTheme(darkTheme = true) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(SafarBlack)
        ) {
            // ── Search + filter bar ───────────────────────────────────────────
            Surface(
                color          = SafarDarkSurface,
                tonalElevation = 2.dp
            ) {
                Row(
                    modifier          = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value         = state.searchQuery,
                        onValueChange = onSearchChange,
                        placeholder   = {
                            Text("Search origin or destination…",
                                color    = SafarTextSecondary,
                                fontSize = 13.sp)
                        },
                        singleLine    = true,
                        leadingIcon   = {
                            Icon(Icons.Rounded.Search, null,
                                tint     = SafarTextSecondary,
                                modifier = Modifier.size(18.dp))
                        },
                        trailingIcon  = if (state.searchQuery.isNotEmpty()) {{
                            IconButton(onClick = { onSearchChange("") }) {
                                Icon(Icons.Rounded.Close, null,
                                    tint     = SafarTextSecondary,
                                    modifier = Modifier.size(16.dp))
                            }
                        }} else null,
                        shape         = RoundedCornerShape(12.dp),
                        colors        = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor      = SafarYellow,
                            unfocusedBorderColor    = SafarDivider,
                            focusedContainerColor   = SafarDarkCard,
                            unfocusedContainerColor = SafarDarkCard,
                            focusedTextColor        = SafarTextPrimary,
                            unfocusedTextColor      = SafarTextPrimary,
                            cursorColor             = SafarYellow
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                    )

                    // Filter button
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(SafarDarkCard)
                            .clickable { onFilterTap() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.FilterList, "Filter",
                            tint     = SafarYellow,
                            modifier = Modifier.size(22.dp))
                    }
                }
            }

            // ── Result count ──────────────────────────────────────────────────
            AnimatedVisibility(visible = !state.isLoading) {
                Text(
                    text     = "${state.rides.size} rides available",
                    color    = SafarTextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }

            // ── Content ───────────────────────────────────────────────────────
            when {
                state.isLoading -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(
                                color       = SafarYellow,
                                modifier    = Modifier.size(32.dp),
                                strokeWidth = 2.5.dp
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Finding rides…",
                                color    = SafarTextSecondary,
                                fontSize = 13.sp)
                        }
                    }
                }

                state.rides.isEmpty() -> {
                    EmptyRidesView(modifier = Modifier.fillMaxSize())
                }

                else -> {
                    LazyColumn(
                        modifier       = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(
                            start  = 16.dp,
                            end    = 16.dp,
                            top    = 4.dp,
                            bottom = 80.dp
                        ),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(state.rides, key = { it.adId }) { ride ->
                            RideListCard(ride = ride, onClick = { onRideClick(ride.adId) })
                        }
                    }
                }
            }
        }
    }
}

// ── Ride card in list ─────────────────────────────────────────────────────────
@Composable
private fun RideListCard(ride: RideAdListItem, onClick: () -> Unit) {
    val sdf    = remember { SimpleDateFormat("EEE dd MMM • hh:mm a", Locale.getDefault()) }
    val isOpen = ride.status.equals("Open", ignoreCase = true)

    Card(
        shape     = RoundedCornerShape(16.dp),
        colors    = CardDefaults.cardColors(containerColor = SafarDarkCard),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier  = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(16.dp)) {

            // Top row: status + seats
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.CenterVertically
            ) {
                // Status pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (isOpen) StatusOpen.copy(alpha = 0.15f)
                            else StatusFilled.copy(alpha = 0.15f)
                        )
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        ride.status,
                        color      = if (isOpen) StatusOpen else StatusFilled,
                        fontSize   = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Seats pill
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Rounded.EventSeat, null,
                        tint     = SafarYellowDark,
                        modifier = Modifier.size(14.dp))
                    Text("${ride.seats} seats",
                        color    = SafarTextSecondary,
                        fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Route dots
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(9.dp).clip(CircleShape)
                    .background(Color(0xFF34C759)))
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    ride.origin,
                    fontWeight = FontWeight.SemiBold,
                    fontSize   = 15.sp,
                    color      = SafarTextPrimary,
                    maxLines   = 1,
                    overflow   = TextOverflow.Ellipsis,
                    modifier   = Modifier.weight(1f)
                )
            }

            Row(modifier = Modifier.padding(start = 3.5.dp, top = 3.dp, bottom = 3.dp)) {
                Box(modifier = Modifier.width(2.dp).height(14.dp)
                    .background(SafarDivider))
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(9.dp).clip(CircleShape)
                    .background(SafarYellow))
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    ride.destination,
                    fontWeight = FontWeight.SemiBold,
                    fontSize   = 15.sp,
                    color      = SafarTextPrimary,
                    maxLines   = 1,
                    overflow   = TextOverflow.Ellipsis,
                    modifier   = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = SafarDivider, thickness = 0.5.dp)
            Spacer(modifier = Modifier.height(10.dp))

            // Bottom meta row
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Rounded.Schedule, null,
                        tint     = SafarYellowDark,
                        modifier = Modifier.size(13.dp))
                    Text(sdf.format(Date(ride.departureTime)),
                        color    = SafarTextSecondary,
                        fontSize = 11.sp)
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Rounded.Person, null,
                        tint     = SafarTextSecondary,
                        modifier = Modifier.size(13.dp))
                    Text(ride.postedBy,
                        color    = SafarTextSecondary,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

// ── Empty state ───────────────────────────────────────────────────────────────
@Composable
private fun EmptyRidesView(modifier: Modifier = Modifier) {
    Column(
        modifier            = modifier,
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Rounded.SearchOff, null,
            tint     = SafarTextSecondary.copy(alpha = 0.3f),
            modifier = Modifier.size(72.dp))
        Spacer(modifier = Modifier.height(16.dp))
        Text("No rides found",
            fontWeight = FontWeight.Bold,
            fontSize   = 18.sp,
            color      = SafarTextSecondary)
        Spacer(modifier = Modifier.height(6.dp))
        Text("Try a different search or check back later",
            fontSize = 13.sp,
            color    = SafarTextSecondary.copy(alpha = 0.6f))
    }
}

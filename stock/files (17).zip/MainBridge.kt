package com.safar.app.views.activities

import android.widget.FrameLayout
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentContainerView
import com.safar.app.R
import com.safar.app.views.ui.theme.SafarDarkSurface
import com.safar.app.views.ui.theme.SafarTextSecondary
import com.safar.app.views.ui.theme.SafarTheme
import com.safar.app.views.ui.theme.SafarYellow

/**
 * WHERE TO PASTE: views/activities/MainBridge.kt
 *
 * In MainActivity.java:
 *   REMOVE: binding field, inflate, setContentView
 *   REMOVE: binding.bottomNav.setOnItemSelectedListener
 *   ADD field:    private MainStateHolder stateHolder;
 *   ADD onCreate: stateHolder = new MainStateHolder();
 *                 MainBridgeKt.setupComposeUI(this, stateHolder);
 *                 if (savedInstanceState == null) {
 *                     loadFragment(new MapFragment());
 *                 }
 *
 *   ADD method:
 *     public void onTabSelected(int index) {
 *         stateHolder.setSelectedTab(index);
 *         switch (index) {
 *             case 0: loadFragment(new MapFragment()); break;
 *             case 1: loadFragment(new ListFragment()); break;
 *             case 2: loadFragment(new InboxFragment()); break;
 *             case 3: startActivity(new Intent(this, ProfileActivity.class)); break;
 *         }
 *     }
 *
 *   CHANGE handleIntent():
 *     was: binding.bottomNav.setSelectedItemId(R.id.nav_list)
 *     now: onTabSelected(1)
 *
 *   loadFragment() — COMPLETELY UNCHANGED, stays exactly as-is
 */

sealed class MainTab(
    val index : Int,
    val label : String,
    val icon  : ImageVector
) {
    object Map     : MainTab(0, "Map",    Icons.Rounded.Map)
    object Rides   : MainTab(1, "Rides",  Icons.Rounded.DirectionsCar)
    object Inbox   : MainTab(2, "Inbox",  Icons.Rounded.Inbox)
    object Profile : MainTab(3, "Profile",Icons.Rounded.Person)
}

private val mainTabs = listOf(MainTab.Map, MainTab.Rides, MainTab.Inbox, MainTab.Profile)

class MainStateHolder {
    var selectedTab by mutableStateOf(0)

    fun setSelectedTab(index: Int) { selectedTab = index }
    fun getSelectedTab(): Int      = selectedTab
}

@OptIn(ExperimentalMaterial3Api::class)
fun MainActivity.setupComposeUI(stateHolder: MainStateHolder) {
    setContent {
        SafarTheme(darkTheme = true) {
            androidx.compose.foundation.layout.Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Fragment host — all fragment content lives here
                androidx.compose.ui.viewinterop.AndroidView(
                    factory = { ctx ->
                        FragmentContainerView(ctx).apply {
                            id = R.id.fragmentContainer
                            layoutParams = FrameLayout.LayoutParams(
                                FrameLayout.LayoutParams.MATCH_PARENT,
                                FrameLayout.LayoutParams.MATCH_PARENT
                            )
                        }
                    },
                    modifier = Modifier.weight(1f)
                )

                // Compose NavigationBar (replaces XML BottomNavigationView)
                NavigationBar(
                    containerColor = SafarDarkSurface,
                    tonalElevation = 0.dp
                ) {
                    mainTabs.forEach { tab ->
                        val selected = stateHolder.selectedTab == tab.index
                        NavigationBarItem(
                            selected = selected,
                            onClick  = { onTabSelected(tab.index) },
                            icon     = {
                                Icon(tab.icon, contentDescription = tab.label)
                            },
                            label    = {
                                Text(tab.label, style = MaterialTheme.typography.labelSmall)
                            },
                            colors   = NavigationBarItemDefaults.colors(
                                selectedIconColor   = SafarYellow,
                                selectedTextColor   = SafarYellow,
                                unselectedIconColor = SafarTextSecondary,
                                unselectedTextColor = SafarTextSecondary,
                                indicatorColor      = SafarYellow.copy(alpha = 0.15f)
                            )
                        )
                    }
                }
            }
        }
    }
}

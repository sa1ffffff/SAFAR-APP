package com.safar.app.views.activities

import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.safar.app.views.ui.screens.SafetyScreen
import com.safar.app.views.ui.theme.SafarTheme

/**
 * WHERE TO PASTE: views/activities/SafetyBridge.kt
 *
 * In SafetyActivity.java:
 *   REMOVE: binding field, inflate, setContentView, btnIUnderstand click listener
 *   ADD field:    private SafetyStateHolder stateHolder;
 *   ADD onCreate: stateHolder = new SafetyStateHolder();
 *                 SafetyBridgeKt.setupComposeUI(this, stateHolder);
 *   ADD method:   public void handleIUnderstand() { ... session.setSafetyShown(true); navigate... }
 */
class SafetyStateHolder {
    var isChecked by mutableStateOf(false)

    fun getIsChecked(): Boolean = isChecked
}

fun SafetyActivity.setupComposeUI(stateHolder: SafetyStateHolder) {
    setContent {
        SafarTheme(darkTheme = true) {
            SafetyScreen(
                isChecked       = stateHolder.isChecked,
                onCheckedChange = { stateHolder.isChecked = it },
                onIUnderstand   = { handleIUnderstand() }
            )
        }
    }
}

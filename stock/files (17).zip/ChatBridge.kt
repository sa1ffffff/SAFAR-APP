package com.safar.app.views.activities

import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf
import com.safar.app.views.ui.screens.ChatMessage
import com.safar.app.views.ui.screens.ChatScreen
import com.safar.app.views.ui.theme.SafarTheme

/**
 * WHERE TO PASTE: views/activities/ChatBridge.kt
 *
 * In ChatActivity.java:
 *   REMOVE: binding field, inflate, setContentView
 *   REMOVE: adapter, RecyclerView, LinearLayoutManager setup
 *   REMOVE: binding.btnSend.setOnClickListener, binding.etMessage listener
 *   ADD field:    private ChatStateHolder stateHolder;
 *   ADD onCreate: stateHolder = new ChatStateHolder();
 *                 String disclaimer = getString(R.string.chat_disclaimer);
 *                 ChatBridgeKt.setupComposeUI(this, stateHolder, otherUserName, disclaimer);
 *
 *   CHANGE onMessageReceived():
 *     Convert your ChatMessage model to ui.screens.ChatMessage then:
 *     stateHolder.addMessage(uiMsg);
 *     (was: adapter.addMessage + scrollToPosition)
 *
 *   ADD method:
 *     public void handleSend(String text) {
 *         ChatMessage msg = new ChatMessage(currentUid, session.getUserName(), text, ChatMessage.TYPE_TEXT);
 *         presenter.sendMessage(msg);
 *     }
 */
class ChatStateHolder {
    val messages  = mutableStateListOf<ChatMessage>()
    var isLoading by mutableStateOf(false)

    fun addMessage(msg: ChatMessage)        { messages.add(msg) }
    fun setMessages(list: List<ChatMessage>) {
        messages.clear()
        messages.addAll(list)
    }
    fun setLoading(loading: Boolean) { isLoading = loading }
}

fun ChatActivity.setupComposeUI(
    stateHolder   : ChatStateHolder,
    peerName      : String,
    disclaimerText: String
) {
    setContent {
        SafarTheme(darkTheme = true) {
            ChatScreen(
                peerName       = peerName,
                messages       = stateHolder.messages,
                disclaimerText = disclaimerText,
                onSend         = { text -> handleSend(text) },
                onBack         = { onBackPressed() }
            )
        }
    }
}

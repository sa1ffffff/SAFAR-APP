package com.safar.app.views.activities

import androidx.activity.compose.setContent
import com.safar.app.views.ui.screens.SplashScreen
import com.safar.app.views.ui.theme.SafarTheme

/**
 * WHERE TO PASTE: views/activities/SplashBridge.kt
 *
 * In SplashActivity.java → onCreate:
 *   REMOVE: setContentView(R.layout.activity_splash)
 *   ADD:    SplashBridgeKt.setupComposeUI(this)
 *
 * The Handler delay + routing logic in SplashActivity stays 100% unchanged.
 */
fun SplashActivity.setupComposeUI() {
    setContent {
        SafarTheme(darkTheme = true) {
            SplashScreen()
        }
    }
}

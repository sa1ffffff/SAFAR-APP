package com.safar.app.views.activities

import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.safar.app.views.ui.screens.AdDetailScreen
import com.safar.app.views.ui.screens.AdDetailUiState
import com.safar.app.views.ui.screens.JoinRequest
import com.safar.app.views.ui.theme.SafarTheme

/**
 * WHERE TO PASTE: views/activities/AdDetailBridge.kt
 *
 * AdDetailActivity.java was NOT uploaded so here's the full pattern:
 *
 * public class AdDetailActivity extends AppCompatActivity {
 *     private AdDetailStateHolder stateHolder;
 *     private AdsPresenter presenter;   // your existing presenter
 *
 *     @Override protected void onCreate(Bundle savedInstanceState) {
 *         super.onCreate(savedInstanceState);
 *         String adId = getIntent().getStringExtra(AppConstants.KEY_AD_ID);
 *         stateHolder = new AdDetailStateHolder();
 *         stateHolder.setLoading(true);
 *         AdDetailBridgeKt.setupComposeUI(this, stateHolder);
 *         presenter = new AdsPresenter(this);
 *         presenter.loadAdById(adId);   // populate stateHolder in callback
 *     }
 *
 *     public void handleMarkFilled() { presenter.markAdFilled(adId); }
 *     public void handleDeleteAd()   { ... AlertDialog → presenter.deleteAd(adId) ... }
 *     public void handleSendRequest(){ presenter.sendJoinRequest(adId, currentUid); }
 *     public void handleAccept(String requestId) { presenter.acceptRequest(requestId); }
 *     public void handleReject(String requestId) { presenter.rejectRequest(requestId); }
 * }
 */
class AdDetailStateHolder {
    var state by mutableStateOf(AdDetailUiState())
        private set

    fun setLoading(loading: Boolean)             { state = state.copy(isLoading = loading) }
    fun setOrigin(origin: String)                { state = state.copy(origin = origin) }
    fun setDestination(dest: String)             { state = state.copy(destination = dest) }
    fun setDepartureTime(time: String)           { state = state.copy(departureTime = time) }
    fun setSeats(seats: String)                  { state = state.copy(seats = seats) }
    fun setPostedBy(name: String)                { state = state.copy(postedBy = name) }
    fun setVehicle(vehicle: String)              { state = state.copy(vehicle = vehicle) }
    fun setStatus(status: String)                { state = state.copy(status = status) }
    fun setNotes(notes: String)                  { state = state.copy(notes = notes) }
    fun setIsOwner(isOwner: Boolean)             { state = state.copy(isOwner = isOwner) }
    fun setRequests(list: List<JoinRequest>)     { state = state.copy(joinRequests = list) }
}

fun AdDetailActivity.setupComposeUI(stateHolder: AdDetailStateHolder) {
    setContent {
        SafarTheme(darkTheme = false) {
            AdDetailScreen(
                uiState         = stateHolder.state,
                onBack          = { onBackPressed() },
                onMarkFilled    = { handleMarkFilled() },
                onDeleteAd      = { handleDeleteAd() },
                onSendRequest   = { handleSendRequest() },
                onAcceptRequest = { requestId -> handleAccept(requestId) },
                onRejectRequest = { requestId -> handleReject(requestId) }
            )
        }
    }
}

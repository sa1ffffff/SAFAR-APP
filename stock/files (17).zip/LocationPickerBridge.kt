package com.safar.app.views.activities

import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.safar.app.views.ui.screens.LocationPickerScreen
import com.safar.app.views.ui.theme.SafarTheme

/**
 * WHERE TO PASTE: views/activities/LocationPickerBridge.kt
 *
 * In LocationPickerActivity.java:
 *   REMOVE: setContentView(R.layout.activity_location_picker)
 *   REMOVE: all findViewById() calls (etSearch, etPlaceName, btnConfirm, btnSearch,
 *           btnZoomIn, btnZoomOut, btnMyLocation)
 *   REMOVE: setSupportActionBar + title setup (Compose toolbar handles this)
 *   REMOVE: all setOnClickListener calls
 *   ADD field:    private LocationPickerStateHolder stateHolder;
 *   ADD onCreate: String title = getIntent().getStringExtra(EXTRA_TITLE);
 *                 stateHolder = new LocationPickerStateHolder();
 *                 LocationPickerBridgeKt.setupComposeUI(this, stateHolder, title != null ? title : "Pick Location");
 *
 *   CHANGE onMapReady() — replace binding references:
 *     etPlaceName.setHint("Detecting…")     → stateHolder.setPlaceNameHint("Detecting…")
 *     btnConfirm.setEnabled(false)           → stateHolder.setConfirmEnabled(false)
 *
 *   CHANGE reverseGeocode() — replace binding references:
 *     etPlaceName.setText(detected)          → stateHolder.setPlaceName(detected)
 *     etPlaceName.setHint(...)               → stateHolder.setPlaceNameHint(...)
 *     btnConfirm.setEnabled(true)            → stateHolder.setConfirmEnabled(true)
 *
 *   ADD methods:
 *     public void bindMapView(MapView mv)      { this.mapView = mv; mv.getMapAsync(this); }
 *     public void handleZoomIn()               { if (googleMap!=null) googleMap.animateCamera(CameraUpdateFactory.zoomIn()); }
 *     public void handleZoomOut()              { if (googleMap!=null) googleMap.animateCamera(CameraUpdateFactory.zoomOut()); }
 *     public void handleMyLocation()           { requestLocationAndJump(); }
 *     public void handleSearch(String query)   { searchLocation(query); hideKeyboard(); }
 *     public void handleConfirm(String name)   { ... setResult(RESULT_OK, ...); finish(); }
 */
class LocationPickerStateHolder {
    var placeName         by mutableStateOf("")
    var placeNameHint     by mutableStateOf("Move map to detect, or type a name")
    var isConfirmEnabled  by mutableStateOf(false)

    fun setPlaceName(name: String)           { placeName = name }
    fun setPlaceNameHint(hint: String)       { placeNameHint = hint }
    fun setConfirmEnabled(enabled: Boolean)  { isConfirmEnabled = enabled }
    fun getPlaceName(): String               = placeName
}

fun LocationPickerActivity.setupComposeUI(
    stateHolder : LocationPickerStateHolder,
    title       : String
) {
    setContent {
        SafarTheme(darkTheme = true) {
            LocationPickerScreen(
                title             = title,
                placeName         = stateHolder.placeName,
                isConfirmEnabled  = stateHolder.isConfirmEnabled,
                onPlaceNameChange = { stateHolder.setPlaceName(it) },
                onSearchQuery     = { query -> handleSearch(query) },
                onZoomIn          = { handleZoomIn() },
                onZoomOut         = { handleZoomOut() },
                onMyLocation      = { handleMyLocation() },
                onConfirm         = { handleConfirm(stateHolder.getPlaceName()) },
                onBack            = { onBackPressed() },
                onMapReady        = { mapView -> bindMapView(mapView) }
            )
        }
    }
}

package com.safar.app.views.ui.screens

import android.os.Bundle
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.google.android.gms.maps.MapView
import com.safar.app.views.ui.theme.*

/**
 * WHERE TO PASTE: ui/screens/MapScreen.kt
 *
 * Used by MapFragment.java → replace onCreateView with ComposeView.
 * [onMapReady]  → passes MapView ref to your Java fragment for getMapAsync()
 * [onPostRide]  → navigates to PostAdActivity
 * [onSearchRide]→ optional search action
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(
    onMapReady  : (MapView) -> Unit = {},
    onPostRide  : () -> Unit        = {},
    onSearchRide: () -> Unit        = {}
) {
    SafarTheme(darkTheme = true) {
        Box(modifier = Modifier.fillMaxSize()) {

            // ── Full-screen Google Map ─────────────────────────────────────────
            SafarMapView(
                modifier   = Modifier.fillMaxSize(),
                onMapReady = onMapReady
            )

            // ── Top search bar overlay ────────────────────────────────────────
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Surface(
                    shape         = RoundedCornerShape(16.dp),
                    color         = SafarDarkSurface.copy(alpha = 0.95f),
                    tonalElevation = 4.dp,
                    modifier      = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier          = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Rounded.Search,
                            contentDescription = null,
                            tint     = SafarTextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            "Search rides near you…",
                            color    = SafarTextSecondary,
                            fontSize = 14.sp,
                            modifier = Modifier
                                .weight(1f)
                                .noRippleClickable { onSearchRide() }
                        )
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(SafarYellow)
                        )
                    }
                }
            }

            // ── FAB — Post a Ride ──────────────────────────────────────────────
            ExtendedFloatingActionButton(
                onClick           = onPostRide,
                containerColor    = SafarYellow,
                contentColor      = SafarBlack,
                shape             = RoundedCornerShape(16.dp),
                modifier          = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 24.dp)
                    .navigationBarsPadding()
            ) {
                Icon(
                    Icons.Rounded.AddCircle,
                    contentDescription = "Post Ride",
                    modifier           = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    "Post a Ride",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize   = 15.sp
                )
            }
        }
    }
}

// Simple clickable without ripple for the search bar
private fun Modifier.noRippleClickable(onClick: () -> Unit): Modifier =
    this.then(Modifier.clickable(
        indication         = null,
        interactionSource  = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
        onClick            = onClick
    ))

package com.safar.app.views.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import com.safar.app.views.ui.theme.*

// ── UI models ─────────────────────────────────────────────────────────────────
enum class InboxItemType { CHAT, JOIN_REQUEST }

data class InboxItem(
    val id           : String,
    val type         : InboxItemType,
    val title        : String,          // peer name or ride route
    val subtitle     : String,          // last message or request status
    val timestamp    : String,          // formatted "3:45 PM" or "Mon"
    val unreadCount  : Int    = 0,
    val adId         : String = "",
    val chatRoomId   : String = "",
    val peerName     : String = "",
    val statusLabel  : String = "",     // "Pending" / "Accepted" / "Rejected"
    val isRequest    : Boolean = false
)

data class InboxUiState(
    val items     : List<InboxItem> = emptyList(),
    val isLoading : Boolean         = false
)

/**
 * WHERE TO PASTE: ui/screens/InboxScreen.kt
 * Used by InboxFragment.java — replace onCreateView with ComposeView.
 *
 * [onChatOpen]    → open ChatActivity with chatRoomId + peerName
 * [onRequestOpen] → open AdDetailActivity with adId
 */
@Composable
fun InboxScreen(
    state         : InboxUiState    = InboxUiState(),
    onChatOpen    : (String, String) -> Unit = { _, _ -> },  // chatRoomId, peerName
    onRequestOpen : (String) -> Unit         = {}             // adId
) {
    SafarTheme(darkTheme = true) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(SafarBlack)
        ) {
            // ── Header ─────────────────────────────────────────────────────────
            Surface(
                color          = SafarDarkSurface,
                tonalElevation = 2.dp
            ) {
                Row(
                    modifier          = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Inbox",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize   = 22.sp,
                            color      = SafarTextPrimary)
                        val unread = state.items.sumOf { it.unreadCount }
                        if (unread > 0) {
                            Text("$unread unread",
                                fontSize = 12.sp,
                                color    = SafarYellow)
                        }
                    }
                    Icon(Icons.Rounded.Notifications, null,
                        tint     = SafarTextSecondary,
                        modifier = Modifier.size(22.dp))
                }
            }

            // ── Content ────────────────────────────────────────────────────────
            when {
                state.isLoading -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(
                            color       = SafarYellow,
                            modifier    = Modifier.size(32.dp),
                            strokeWidth = 2.5.dp
                        )
                    }
                }

                state.items.isEmpty() -> {
                    EmptyInboxView(modifier = Modifier.fillMaxSize())
                }

                else -> {
                    // Separate chats and requests
                    val chats    = state.items.filter { it.type == InboxItemType.CHAT }
                    val requests = state.items.filter { it.type == InboxItemType.JOIN_REQUEST }

                    LazyColumn(
                        modifier       = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 80.dp)
                    ) {
                        // Join requests section
                        if (requests.isNotEmpty()) {
                            item {
                                InboxSectionHeader(
                                    title = "Join Requests",
                                    count = requests.size
                                )
                            }
                            items(requests, key = { it.id }) { item ->
                                InboxRequestRow(
                                    item    = item,
                                    onClick = { onRequestOpen(item.adId) }
                                )
                            }
                        }

                        // Chats section
                        if (chats.isNotEmpty()) {
                            item {
                                InboxSectionHeader(
                                    title = "Messages",
                                    count = chats.size
                                )
                            }
                            items(chats, key = { it.id }) { item ->
                                InboxChatRow(
                                    item    = item,
                                    onClick = { onChatOpen(item.chatRoomId, item.peerName) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ── Section header ────────────────────────────────────────────────────────────
@Composable
private fun InboxSectionHeader(title: String, count: Int) {
    Row(
        modifier          = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title,
            fontWeight = FontWeight.Bold,
            fontSize   = 13.sp,
            color      = SafarTextSecondary)
        Spacer(modifier = Modifier.width(8.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(SafarDarkCard)
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Text("$count",
                color    = SafarYellow,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold)
        }
    }
}

// ── Chat row ──────────────────────────────────────────────────────────────────
@Composable
private fun InboxChatRow(item: InboxItem, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Avatar
        Box(
            modifier         = Modifier
                .size(50.dp)
                .clip(CircleShape)
                .background(SafarYellow.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                item.peerName.firstOrNull()?.uppercaseChar()?.toString() ?: "?",
                fontWeight = FontWeight.Bold,
                fontSize   = 20.sp,
                color      = SafarYellow
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(item.title,
                    fontWeight = if (item.unreadCount > 0) FontWeight.Bold else FontWeight.Normal,
                    fontSize   = 15.sp,
                    color      = SafarTextPrimary)
                Text(item.timestamp,
                    fontSize = 11.sp,
                    color    = if (item.unreadCount > 0) SafarYellow else SafarTextSecondary)
            }
            Spacer(modifier = Modifier.height(3.dp))
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.CenterVertically
            ) {
                Text(
                    item.subtitle,
                    fontSize   = 13.sp,
                    color      = if (item.unreadCount > 0) SafarTextPrimary
                                 else SafarTextSecondary,
                    maxLines   = 1,
                    overflow   = TextOverflow.Ellipsis,
                    modifier   = Modifier.weight(1f)
                )
                if (item.unreadCount > 0) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier         = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(SafarYellow),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "${item.unreadCount}",
                            color      = SafarBlack,
                            fontSize   = 10.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }
    }
    HorizontalDivider(
        color    = SafarDivider.copy(alpha = 0.5f),
        modifier = Modifier.padding(start = 78.dp)
    )
}

// ── Join request row ──────────────────────────────────────────────────────────
@Composable
private fun InboxRequestRow(item: InboxItem, onClick: () -> Unit) {
    val statusColor = when (item.statusLabel.lowercase()) {
        "accepted" -> StatusOpen
        "rejected" -> StatusFilled
        else       -> SafarYellow
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier         = Modifier
                .size(50.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(SafarDarkCard),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.DirectionsCar, null,
                tint     = SafarYellowDark,
                modifier = Modifier.size(24.dp))
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(item.title,
                    fontWeight = FontWeight.SemiBold,
                    fontSize   = 14.sp,
                    color      = SafarTextPrimary,
                    maxLines   = 1,
                    overflow   = TextOverflow.Ellipsis,
                    modifier   = Modifier.weight(1f))
                Text(item.timestamp,
                    fontSize = 11.sp,
                    color    = SafarTextSecondary)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(item.subtitle,
                    fontSize = 12.sp,
                    color    = SafarTextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false))
                if (item.statusLabel.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(statusColor.copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(item.statusLabel,
                            color    = statusColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.width(8.dp))
        Icon(Icons.Rounded.ChevronRight, null,
            tint     = SafarTextSecondary,
            modifier = Modifier.size(18.dp))
    }
    HorizontalDivider(
        color    = SafarDivider.copy(alpha = 0.5f),
        modifier = Modifier.padding(start = 78.dp)
    )
}

// ── Empty state ───────────────────────────────────────────────────────────────
@Composable
private fun EmptyInboxView(modifier: Modifier = Modifier) {
    Column(
        modifier            = modifier,
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Rounded.Inbox, null,
            tint     = SafarTextSecondary.copy(alpha = 0.25f),
            modifier = Modifier.size(72.dp))
        Spacer(modifier = Modifier.height(16.dp))
        Text("No messages yet",
            fontWeight = FontWeight.Bold,
            fontSize   = 18.sp,
            color      = SafarTextSecondary)
        Spacer(modifier = Modifier.height(6.dp))
        Text("Your chats and ride requests will appear here",
            fontSize = 13.sp,
            color    = SafarTextSecondary.copy(alpha = 0.6f))
    }
}

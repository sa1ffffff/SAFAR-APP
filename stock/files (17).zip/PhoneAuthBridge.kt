package com.safar.app.views.activities

import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.safar.app.views.ui.screens.PhoneAuthScreen
import com.safar.app.views.ui.theme.SafarTheme

/**
 * WHERE TO PASTE: views/activities/PhoneAuthBridge.kt
 *
 * In PhoneAuthActivity.java:
 *   REMOVE: binding field, inflate, setContentView, btnContinue click listener
 *   ADD field:    private PhoneAuthStateHolder stateHolder;
 *   ADD onCreate: stateHolder = new PhoneAuthStateHolder();
 *                 PhoneAuthBridgeKt.setupComposeUI(this, stateHolder);
 *   ADD method:   public void handleContinue(String fullPhone) { ... startActivity OtpVerify }
 */
class PhoneAuthStateHolder {
    var phone       by mutableStateOf("")
    var countryCode by mutableStateOf("+92")

    fun getPhone(): String       = phone
    fun getCountryCode(): String = countryCode
    fun setCountryCode(code: String) { countryCode = code }
}

fun PhoneAuthActivity.setupComposeUI(stateHolder: PhoneAuthStateHolder) {
    setContent {
        SafarTheme(darkTheme = true) {
            PhoneAuthScreen(
                phone         = stateHolder.phone,
                countryCode   = stateHolder.countryCode,
                onPhoneChange = { stateHolder.phone = it },
                onContinue    = {
                    handleContinue(stateHolder.countryCode + stateHolder.phone.trim())
                }
            )
        }
    }
}

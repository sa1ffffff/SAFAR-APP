package com.safar.app.views.activities

import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.safar.app.views.ui.screens.ProfileScreen
import com.safar.app.views.ui.screens.ProfileUiState
import com.safar.app.views.ui.theme.SafarTheme

/**
 * WHERE TO PASTE: views/activities/ProfileBridge.kt
 *
 * In ProfileActivity.java:
 *   REMOVE: binding field, inflate, setContentView, setSupportActionBar
 *   REMOVE: binding.btnMyRides.setOnClickListener, binding.btnLogout.setOnClickListener
 *   ADD field:    private ProfileStateHolder stateHolder;
 *   ADD onCreate: stateHolder = new ProfileStateHolder();
 *                 ProfileBridgeKt.setupComposeUI(this, stateHolder);
 *
 *   CHANGE loadProfile():
 *     Replace all binding.tvXxx.setText() calls with:
 *     stateHolder.setName(...)
 *     stateHolder.setPhone(...)
 *     stateHolder.setTotalRides(...)
 *     stateHolder.setRating(rating, count)
 *
 *   ADD methods:
 *     public void navigateToMyRides() { startActivity(new Intent(this, MyAdsActivity.class)); }
 *     public void showLogoutDialog() { ... AlertDialog ... session.logout ... }
 */
class ProfileStateHolder {
    var state by mutableStateOf(ProfileUiState())
        private set

    fun setLoading(loading: Boolean)           { state = state.copy(isLoading = loading) }
    fun setName(name: String)                  { state = state.copy(name = name) }
    fun setPhone(phone: String)                { state = state.copy(phone = phone) }
    fun setTotalRides(n: Int)                  { state = state.copy(totalRides = n) }
    fun setRating(rating: Float, count: Int)   { state = state.copy(rating = rating, ratingCount = count) }
}

fun ProfileActivity.setupComposeUI(stateHolder: ProfileStateHolder) {
    setContent {
        SafarTheme(darkTheme = false) {
            ProfileScreen(
                state     = stateHolder.state,
                onMyRides = { navigateToMyRides() },
                onLogout  = { showLogoutDialog() },
                onBack    = { onBackPressed() }
            )
        }
    }
}

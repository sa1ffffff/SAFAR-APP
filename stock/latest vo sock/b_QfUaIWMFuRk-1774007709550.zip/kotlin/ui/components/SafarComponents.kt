package com.safar.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.safar.ui.theme.SafarTheme

/**
 * SafarComponents - Enterprise-grade reusable UI components
 * 
 * Design Philosophy:
 * - Uber-inspired minimalist components
 * - Consistent styling across the app
 * - Accessibility-first approach
 * - Smooth micro-interactions
 */

// ═══════════════════════════════════════════════════════════════════════════════
// BUTTONS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Primary action button - Uber style
 */
@Composable
fun SafarPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    isLoading: Boolean = false,
    leadingIcon: ImageVector? = null
) {
    Button(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp),
        enabled = enabled && !isLoading,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = SafarTheme.colors.onBackground,
            contentColor = SafarTheme.colors.background,
            disabledContainerColor = SafarTheme.colors.surface,
            disabledContentColor = SafarTheme.colors.onSurfaceVariant
        ),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = 0.dp,
            pressedElevation = 0.dp
        )
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.size(24.dp),
                color = SafarTheme.colors.background,
                strokeWidth = 2.dp
            )
        } else {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                leadingIcon?.let {
                    Icon(
                        imageVector = it,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Text(
                    text = text,
                    style = SafarTheme.typography.button,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

/**
 * Secondary/outline button
 */
@Composable
fun SafarSecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    leadingIcon: ImageVector? = null
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp),
        enabled = enabled,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = SafarTheme.colors.onBackground
        ),
        border = ButtonDefaults.outlinedButtonBorder(enabled = enabled).copy(
            brush = Brush.linearGradient(
                colors = listOf(
                    SafarTheme.colors.border,
                    SafarTheme.colors.border
                )
            )
        )
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            leadingIcon?.let {
                Icon(
                    imageVector = it,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
            }
            Text(
                text = text,
                style = SafarTheme.typography.button,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

/**
 * Icon button with background
 */
@Composable
fun SafarIconButton(
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    contentDescription: String? = null,
    backgroundColor: Color = SafarTheme.colors.surface,
    iconColor: Color = SafarTheme.colors.onSurface,
    size: Dp = 48.dp
) {
    Surface(
        onClick = onClick,
        modifier = modifier.size(size),
        shape = CircleShape,
        color = backgroundColor
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = iconColor,
                modifier = Modifier.size(size * 0.5f)
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// CARDS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Standard card component
 */
@Composable
fun SafarCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = SafarTheme.colors.surfaceElevated,
        onClick = onClick ?: {}
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

/**
 * Elevated card with shadow
 */
@Composable
fun SafarElevatedCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = SafarTheme.colors.surfaceElevated,
        shadowElevation = 8.dp,
        onClick = onClick ?: {}
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// TOP BARS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Standard top app bar
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SafarTopBar(
    title: String,
    onNavigateBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    TopAppBar(
        title = {
            Text(
                text = title,
                style = SafarTheme.typography.headlineSmall,
                color = SafarTheme.colors.onBackground,
                fontWeight = FontWeight.SemiBold
            )
        },
        navigationIcon = {
            onNavigateBack?.let {
                IconButton(onClick = it) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Go back",
                        tint = SafarTheme.colors.onBackground
                    )
                }
            }
        },
        actions = actions,
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = SafarTheme.colors.background
        )
    )
}

// ═══════════════════════════════════════════════════════════════════════════════
// BOTTOM NAVIGATION
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Bottom navigation bar item
 */
data class SafarNavItem(
    val icon: ImageVector,
    val selectedIcon: ImageVector = icon,
    val label: String,
    val route: String
)

/**
 * Bottom navigation bar - Uber style
 */
@Composable
fun SafarBottomNavBar(
    items: List<SafarNavItem>,
    selectedRoute: String,
    onItemSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = SafarTheme.colors.surfaceElevated,
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .navigationBarsPadding(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            items.forEach { item ->
                val isSelected = item.route == selectedRoute
                
                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onItemSelected(item.route) }
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = if (isSelected) item.selectedIcon else item.icon,
                        contentDescription = item.label,
                        tint = if (isSelected) {
                            SafarTheme.colors.onBackground
                        } else {
                            SafarTheme.colors.onSurfaceVariant
                        },
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = item.label,
                        style = SafarTheme.typography.labelSmall,
                        color = if (isSelected) {
                            SafarTheme.colors.onBackground
                        } else {
                            SafarTheme.colors.onSurfaceVariant
                        }
                    )
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// TEXT FIELDS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Styled text field
 */
@Composable
fun SafarTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    label: String? = null,
    placeholder: String? = null,
    leadingIcon: ImageVector? = null,
    trailingIcon: @Composable (() -> Unit)? = null,
    isError: Boolean = false,
    errorMessage: String? = null,
    singleLine: Boolean = true
) {
    Column(modifier = modifier) {
        label?.let {
            Text(
                text = it,
                style = SafarTheme.typography.labelMedium,
                color = SafarTheme.colors.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
        
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = placeholder?.let {
                {
                    Text(
                        text = it,
                        style = SafarTheme.typography.bodyLarge,
                        color = SafarTheme.colors.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                }
            },
            leadingIcon = leadingIcon?.let {
                {
                    Icon(
                        imageVector = it,
                        contentDescription = null,
                        tint = SafarTheme.colors.onSurfaceVariant
                    )
                }
            },
            trailingIcon = trailingIcon,
            isError = isError,
            singleLine = singleLine,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = SafarTheme.colors.surface,
                unfocusedContainerColor = SafarTheme.colors.surface,
                focusedBorderColor = SafarTheme.colors.primary,
                unfocusedBorderColor = SafarTheme.colors.border,
                errorBorderColor = SafarTheme.colors.error,
                cursorColor = SafarTheme.colors.primary,
                focusedTextColor = SafarTheme.colors.onSurface,
                unfocusedTextColor = SafarTheme.colors.onSurface
            )
        )
        
        if (isError && errorMessage != null) {
            Text(
                text = errorMessage,
                style = SafarTheme.typography.bodySmall,
                color = SafarTheme.colors.error,
                modifier = Modifier.padding(top = 4.dp, start = 4.dp)
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// LOADING STATES
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Full screen loading indicator
 */
@Composable
fun SafarLoadingScreen(
    message: String = "Loading..."
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(SafarTheme.colors.background),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(48.dp),
                color = SafarTheme.colors.primary,
                strokeWidth = 3.dp
            )
            Text(
                text = message,
                style = SafarTheme.typography.bodyMedium,
                color = SafarTheme.colors.onSurfaceVariant
            )
        }
    }
}

/**
 * Shimmer loading placeholder
 */
@Composable
fun SafarShimmer(
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "shimmer")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.5f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "shimmer_alpha"
    )
    
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(SafarTheme.colors.surface.copy(alpha = alpha))
    )
}

// ═══════════════════════════════════════════════════════════════════════════════
// EMPTY STATES
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Empty state component
 */
@Composable
fun SafarEmptyState(
    icon: ImageVector,
    title: String,
    description: String,
    actionText: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .background(
                    SafarTheme.colors.surface,
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = SafarTheme.colors.onSurfaceVariant,
                modifier = Modifier.size(40.dp)
            )
        }
        
        Text(
            text = title,
            style = SafarTheme.typography.headlineSmall,
            color = SafarTheme.colors.onBackground,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center
        )
        
        Text(
            text = description,
            style = SafarTheme.typography.bodyMedium,
            color = SafarTheme.colors.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        
        if (actionText != null && onAction != null) {
            Spacer(modifier = Modifier.height(8.dp))
            SafarPrimaryButton(
                text = actionText,
                onClick = onAction,
                modifier = Modifier.width(200.dp)
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// BADGES & CHIPS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Status badge
 */
@Composable
fun SafarStatusBadge(
    text: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.15f)
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            style = SafarTheme.typography.labelMedium,
            color = color,
            fontWeight = FontWeight.SemiBold
        )
    }
}

/**
 * Filter chip
 */
@Composable
fun SafarFilterChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    leadingIcon: ImageVector? = null
) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = if (selected) SafarTheme.colors.onBackground else SafarTheme.colors.surface,
        border = if (!selected) {
            androidx.compose.foundation.BorderStroke(
                width = 1.dp,
                color = SafarTheme.colors.border
            )
        } else null
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            leadingIcon?.let {
                Icon(
                    imageVector = it,
                    contentDescription = null,
                    tint = if (selected) SafarTheme.colors.background else SafarTheme.colors.onSurface,
                    modifier = Modifier.size(18.dp)
                )
            }
            Text(
                text = text,
                style = SafarTheme.typography.labelMedium,
                color = if (selected) SafarTheme.colors.background else SafarTheme.colors.onSurface,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// DIVIDERS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Horizontal divider
 */
@Composable
fun SafarDivider(
    modifier: Modifier = Modifier
) {
    HorizontalDivider(
        modifier = modifier,
        thickness = 1.dp,
        color = SafarTheme.colors.divider
    )
}

/**
 * Divider with text
 */
@Composable
fun SafarDividerWithText(
    text: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        HorizontalDivider(
            modifier = Modifier.weight(1f),
            color = SafarTheme.colors.divider
        )
        Text(
            text = text,
            style = SafarTheme.typography.bodySmall,
            color = SafarTheme.colors.onSurfaceVariant
        )
        HorizontalDivider(
            modifier = Modifier.weight(1f),
            color = SafarTheme.colors.divider
        )
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// AVATARS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * User avatar component
 */
@Composable
fun SafarAvatar(
    name: String,
    modifier: Modifier = Modifier,
    imageUrl: String? = null,
    size: Dp = 48.dp,
    onClick: (() -> Unit)? = null
) {
    val initials = name.split(" ")
        .take(2)
        .mapNotNull { it.firstOrNull()?.uppercase() }
        .joinToString("")
    
    Surface(
        modifier = modifier.size(size),
        shape = CircleShape,
        color = SafarTheme.colors.surface,
        onClick = onClick ?: {}
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            // If we had an image loader, we'd use it here
            // For now, show initials
            Text(
                text = initials.ifEmpty { "?" },
                style = SafarTheme.typography.titleMedium,
                color = SafarTheme.colors.onSurface,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

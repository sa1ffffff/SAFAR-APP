package com.safar.app.views.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.safar.app.views.ui.theme.*

/**
 * SAFAR SPLASH SCREEN
 * Enterprise-level animated splash with Uber-inspired design
 * 
 * Features:
 * - Smooth scale and fade animations
 * - Premium gradient background
 * - Staggered reveal animation
 * - Loading indicator with progress
 */
@Composable
fun SplashScreen(
    onAnimationComplete: () -> Unit = {}
) {
    // Animation states
    val logoScale = remember { Animatable(0.6f) }
    val logoAlpha = remember { Animatable(0f) }
    val titleAlpha = remember { Animatable(0f) }
    val taglineAlpha = remember { Animatable(0f) }
    val loaderAlpha = remember { Animatable(0f) }
    
    // Pulsing animation for the logo
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    LaunchedEffect(Unit) {
        // Logo animation sequence
        kotlinx.coroutines.launch {
            logoScale.animateTo(
                targetValue = 1f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessLow
                )
            )
        }
        
        kotlinx.coroutines.launch {
            logoAlpha.animateTo(
                targetValue = 1f,
                animationSpec = tween(400, easing = EaseOutCubic)
            )
        }
        
        kotlinx.coroutines.delay(200)
        
        // Title fade in
        titleAlpha.animateTo(
            targetValue = 1f,
            animationSpec = tween(500, easing = EaseOutCubic)
        )
        
        kotlinx.coroutines.delay(100)
        
        // Tagline fade in
        taglineAlpha.animateTo(
            targetValue = 1f,
            animationSpec = tween(400, easing = EaseOutCubic)
        )
        
        // Loader fade in
        loaderAlpha.animateTo(
            targetValue = 1f,
            animationSpec = tween(300, easing = EaseOutCubic)
        )
        
        // Wait before completing
        kotlinx.coroutines.delay(1500)
        onAnimationComplete()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(SafarBlack),
        contentAlignment = Alignment.Center
    ) {
        // Subtle gradient overlay for depth
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            SafarGreen.copy(alpha = 0.05f),
                            SafarBlack
                        ),
                        radius = 1000f
                    )
                )
        )
        
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 32.dp)
        ) {
            // Logo Container with glow effect
            Box(
                modifier = Modifier
                    .scale(logoScale.value * pulseScale)
                    .alpha(logoAlpha.value),
                contentAlignment = Alignment.Center
            ) {
                // Glow effect behind icon
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(RoundedCornerShape(28.dp))
                        .background(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    SafarGreen.copy(alpha = 0.3f),
                                    SafarGreen.copy(alpha = 0f)
                                )
                            )
                        )
                )
                
                // Icon container
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(SafarGreen.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.DirectionsCar,
                        contentDescription = "Safar",
                        tint = SafarGreen,
                        modifier = Modifier.size(44.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // App Name
            Text(
                text = "SAFAR",
                fontSize = 48.sp,
                fontWeight = FontWeight.Black,
                color = SafarTextPrimary,
                letterSpacing = 6.sp,
                modifier = Modifier
                    .scale(logoScale.value)
                    .alpha(titleAlpha.value)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Tagline
            Text(
                text = "Community Carpool, Made Easy",
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = SafarTextSecondary,
                letterSpacing = 0.5.sp,
                modifier = Modifier.alpha(taglineAlpha.value)
            )
            
            Spacer(modifier = Modifier.height(48.dp))
            
            // Loading indicator
            Box(
                modifier = Modifier.alpha(loaderAlpha.value)
            ) {
                LinearProgressIndicator(
                    modifier = Modifier
                        .width(120.dp)
                        .height(3.dp)
                        .clip(RoundedCornerShape(1.5.dp)),
                    color = SafarGreen,
                    trackColor = SafarDivider
                )
            }
        }

        // Version text at bottom
        Text(
            text = "v1.0.0",
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = SafarTextTertiary.copy(alpha = 0.5f),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 40.dp)
                .alpha(taglineAlpha.value)
        )
    }
}

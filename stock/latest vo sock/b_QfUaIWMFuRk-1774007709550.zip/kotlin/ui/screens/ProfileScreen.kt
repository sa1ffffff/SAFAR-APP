package com.safar.app.views.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.safar.app.views.ui.theme.*

data class ProfileUiState(
    val name: String = "",
    val phone: String = "",
    val email: String = "",
    val totalRides: Int = 0,
    val rating: Float = 0f,
    val ratingCount: Int = 0,
    val isLoading: Boolean = false,
    val isVerified: Boolean = false
)

/**
 * SAFAR PROFILE SCREEN
 * Enterprise-level user profile with Uber-inspired design
 * 
 * Features:
 * - Clean avatar with initials
 * - Stats display (rides, ratings)
 * - Action cards with icons
 * - Premium logout button
 * - Light theme for clarity
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    state: ProfileUiState = ProfileUiState(),
    onMyRides: () -> Unit = {},
    onEditProfile: () -> Unit = {},
    onPaymentMethods: () -> Unit = {},
    onSettings: () -> Unit = {},
    onHelp: () -> Unit = {},
    onPrivacy: () -> Unit = {},
    onLogout: () -> Unit = {},
    onBack: () -> Unit = {}
) {
    SafarTheme(darkTheme = false) {
        Scaffold(
            containerColor = SafarBg,
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            "Profile",
                            fontWeight = FontWeight.Bold,
                            color = SafarTextDark
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(
                                Icons.Rounded.ArrowBackIosNew,
                                "Back",
                                tint = SafarTextDark
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = onSettings) {
                            Icon(
                                Icons.Rounded.Settings,
                                "Settings",
                                tint = SafarTextDark
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = SafarWhite
                    )
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
            ) {
                // ── Avatar & Info Card ────────────────────────────────────────
                ProfileHeaderCard(
                    state = state,
                    onEditProfile = onEditProfile
                )

                Spacer(modifier = Modifier.height(24.dp))

                // ── Stats Section ─────────────────────────────────────────────
                StatsSection(state = state)

                Spacer(modifier = Modifier.height(24.dp))

                // ── Action Cards ──────────────────────────────────────────────
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "ACCOUNT",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = SafarTextMuted,
                        letterSpacing = 1.5.sp,
                        modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                    )
                    
                    ProfileActionCard(
                        icon = Icons.Rounded.DirectionsCar,
                        title = "My Rides",
                        subtitle = "View all your posted and joined rides",
                        onClick = onMyRides
                    )
                    
                    ProfileActionCard(
                        icon = Icons.Rounded.CreditCard,
                        title = "Payment Methods",
                        subtitle = "Manage your payment options",
                        onClick = onPaymentMethods
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "SUPPORT",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = SafarTextMuted,
                        letterSpacing = 1.5.sp,
                        modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
                    )
                    
                    ProfileActionCard(
                        icon = Icons.Rounded.Help,
                        title = "Help & Support",
                        subtitle = "FAQs and contact support",
                        onClick = onHelp
                    )
                    
                    ProfileActionCard(
                        icon = Icons.Rounded.Policy,
                        title = "Privacy Policy",
                        subtitle = "How we handle your data",
                        onClick = onPrivacy
                    )
                    
                    ProfileActionCard(
                        icon = Icons.Rounded.Info,
                        title = "About Safar",
                        subtitle = "Version 1.0.0",
                        onClick = {}
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Logout button
                    OutlinedButton(
                        onClick = onLogout,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.5.dp, SafarError.copy(alpha = 0.5f)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = SafarError
                        )
                    ) {
                        Icon(
                            Icons.Rounded.Logout,
                            null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            "Sign Out",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(40.dp))
                }
            }
        }
    }
}

@Composable
private fun ProfileHeaderCard(
    state: ProfileUiState,
    onEditProfile: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp),
        colors = CardDefaults.cardColors(containerColor = SafarWhite),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Avatar
            Box {
                Box(
                    modifier = Modifier
                        .size(96.dp)
                        .clip(CircleShape)
                        .background(SafarGreen.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    if (state.isLoading) {
                        CircularProgressIndicator(
                            color = SafarGreen,
                            modifier = Modifier.size(32.dp),
                            strokeWidth = 3.dp
                        )
                    } else {
                        Text(
                            text = state.name.firstOrNull()?.uppercaseChar()?.toString() ?: "?",
                            fontSize = 40.sp,
                            fontWeight = FontWeight.Bold,
                            color = SafarGreen
                        )
                    }
                }
                
                // Verified badge
                if (state.isVerified) {
                    Surface(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .size(28.dp),
                        shape = CircleShape,
                        color = SafarSuccess,
                        shadowElevation = 2.dp
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Rounded.CheckCircle,
                                null,
                                tint = SafarWhite,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Name
            Text(
                text = state.name.ifEmpty { "Guest User" },
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp,
                color = SafarTextDark
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Contact info
            if (state.phone.isNotEmpty()) {
                Text(
                    text = state.phone,
                    fontSize = 14.sp,
                    color = SafarTextMuted
                )
            }
            
            if (state.email.isNotEmpty()) {
                Text(
                    text = state.email,
                    fontSize = 14.sp,
                    color = SafarTextMuted
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Edit Profile Button
            OutlinedButton(
                onClick = onEditProfile,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, SafarDividerLight),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = SafarTextDark
                )
            ) {
                Icon(
                    Icons.Rounded.Edit,
                    null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    "Edit Profile",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun StatsSection(state: ProfileUiState) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Rides Stat
        StatCard(
            icon = Icons.Rounded.DirectionsCar,
            value = state.totalRides.toString(),
            label = "Rides",
            color = SafarGreen,
            modifier = Modifier.weight(1f)
        )
        
        // Rating Stat
        StatCard(
            icon = Icons.Rounded.Star,
            value = if (state.ratingCount > 0) String.format("%.1f", state.rating) else "—",
            label = if (state.ratingCount > 0) "${state.ratingCount} reviews" else "No reviews",
            color = SafarWarning,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun StatCard(
    icon: ImageVector,
    value: String,
    label: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SafarWhite),
        elevation = CardDefaults.cardElevation(1.dp),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    icon,
                    null,
                    tint = color,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = value,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = SafarTextDark
                )
                Text(
                    text = label,
                    fontSize = 12.sp,
                    color = SafarTextMuted
                )
            }
        }
    }
}

@Composable
private fun ProfileActionCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SafarWhite),
        elevation = CardDefaults.cardElevation(1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(SafarGreen.copy(alpha = 0.08f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    icon,
                    null,
                    tint = SafarGreen,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    title,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    color = SafarTextDark
                )
                Text(
                    subtitle,
                    fontSize = 12.sp,
                    color = SafarTextMuted
                )
            }
            Icon(
                Icons.Rounded.ChevronRight,
                null,
                tint = SafarTextMuted,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

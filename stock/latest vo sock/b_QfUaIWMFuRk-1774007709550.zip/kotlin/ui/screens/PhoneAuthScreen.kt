package com.safar.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.safar.ui.theme.SafarTheme
import kotlinx.coroutines.delay

/**
 * PhoneAuthScreen - Enterprise-grade phone authentication screen
 * 
 * Design Philosophy:
 * - Uber-inspired dark theme with high contrast elements
 * - Smooth animations for enhanced user experience
 * - Clear visual hierarchy for phone number input
 * - Accessibility-first approach with proper content descriptions
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhoneAuthScreen(
    onNavigateBack: () -> Unit,
    onVerifyPhone: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var phoneNumber by remember { mutableStateOf("") }
    var selectedCountryCode by remember { mutableStateOf("+966") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showContent by remember { mutableStateOf(false) }
    
    val focusRequester = remember { FocusRequester() }
    val keyboardController = LocalSoftwareKeyboardController.current
    
    // Entrance animation
    LaunchedEffect(Unit) {
        delay(100)
        showContent = true
        delay(300)
        focusRequester.requestFocus()
    }
    
    val isValidPhone = phoneNumber.length >= 9
    
    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = SafarTheme.colors.background,
        topBar = {
            TopAppBar(
                title = { },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier
                            .padding(8.dp)
                            .size(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Go back",
                            tint = SafarTheme.colors.onBackground
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SafarTheme.colors.background
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Spacer(modifier = Modifier.height(24.dp))
            
            // Header Section
            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(tween(400)) + slideInVertically(tween(400)) { -it / 2 }
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Enter your mobile number",
                        style = SafarTheme.typography.headlineLarge,
                        color = SafarTheme.colors.onBackground,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Text(
                        text = "We'll send you a verification code to confirm your identity",
                        style = SafarTheme.typography.bodyLarge,
                        color = SafarTheme.colors.onSurfaceVariant,
                        lineHeight = 24.sp
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Phone Input Section
            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(tween(400, delayMillis = 150)) + 
                        slideInVertically(tween(400, delayMillis = 150)) { it / 2 }
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Country Code + Phone Number Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Country Code Selector
                        CountryCodeSelector(
                            selectedCode = selectedCountryCode,
                            onCodeSelected = { selectedCountryCode = it },
                            modifier = Modifier.width(100.dp)
                        )
                        
                        // Phone Number Input
                        PhoneNumberInput(
                            value = phoneNumber,
                            onValueChange = { 
                                if (it.length <= 10 && it.all { char -> char.isDigit() }) {
                                    phoneNumber = it
                                    errorMessage = null
                                }
                            },
                            focusRequester = focusRequester,
                            onDone = {
                                if (isValidPhone) {
                                    keyboardController?.hide()
                                    onVerifyPhone("$selectedCountryCode$phoneNumber")
                                }
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    
                    // Error Message
                    errorMessage?.let { error ->
                        Text(
                            text = error,
                            style = SafarTheme.typography.bodySmall,
                            color = SafarTheme.colors.error,
                            modifier = Modifier.padding(start = 4.dp)
                        )
                    }
                    
                    // Security Notice
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = null,
                            tint = SafarTheme.colors.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Your number is secure and will not be shared",
                            style = SafarTheme.typography.bodySmall,
                            color = SafarTheme.colors.onSurfaceVariant
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.weight(1f))
            
            // Continue Button
            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(tween(400, delayMillis = 300)) + 
                        slideInVertically(tween(400, delayMillis = 300)) { it }
            ) {
                Button(
                    onClick = {
                        if (isValidPhone) {
                            isLoading = true
                            onVerifyPhone("$selectedCountryCode$phoneNumber")
                        } else {
                            errorMessage = "Please enter a valid phone number"
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    enabled = isValidPhone && !isLoading,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SafarTheme.colors.onBackground,
                        contentColor = SafarTheme.colors.background,
                        disabledContainerColor = SafarTheme.colors.surface,
                        disabledContentColor = SafarTheme.colors.onSurfaceVariant
                    )
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = SafarTheme.colors.background,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text(
                            text = "Continue",
                            style = SafarTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

/**
 * Country code selector component with dropdown functionality
 */
@Composable
private fun CountryCodeSelector(
    selectedCode: String,
    onCodeSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    
    val countryCodes = listOf(
        "+966" to "SA",
        "+971" to "AE",
        "+965" to "KW",
        "+968" to "OM",
        "+973" to "BH",
        "+974" to "QA",
        "+962" to "JO",
        "+20" to "EG",
        "+1" to "US"
    )
    
    Box(modifier = modifier) {
        Surface(
            onClick = { expanded = true },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(12.dp),
            color = SafarTheme.colors.surface,
            border = androidx.compose.foundation.BorderStroke(
                width = 1.dp,
                color = SafarTheme.colors.border
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = selectedCode,
                    style = SafarTheme.typography.bodyLarge,
                    color = SafarTheme.colors.onSurface,
                    fontWeight = FontWeight.Medium
                )
            }
        }
        
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier
                .background(SafarTheme.colors.surfaceElevated)
        ) {
            countryCodes.forEach { (code, country) ->
                DropdownMenuItem(
                    text = {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = country,
                                style = SafarTheme.typography.bodyMedium,
                                color = SafarTheme.colors.onSurfaceVariant
                            )
                            Text(
                                text = code,
                                style = SafarTheme.typography.bodyLarge,
                                color = SafarTheme.colors.onSurface,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    },
                    onClick = {
                        onCodeSelected(code)
                        expanded = false
                    }
                )
            }
        }
    }
}

/**
 * Custom phone number input field with enterprise styling
 */
@Composable
private fun PhoneNumberInput(
    value: String,
    onValueChange: (String) -> Unit,
    focusRequester: FocusRequester,
    onDone: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.height(56.dp),
        shape = RoundedCornerShape(12.dp),
        color = SafarTheme.colors.surface,
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = if (value.isNotEmpty()) SafarTheme.colors.primary else SafarTheme.colors.border
        )
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
                .focusRequester(focusRequester),
            textStyle = SafarTheme.typography.headlineSmall.copy(
                color = SafarTheme.colors.onSurface,
                fontWeight = FontWeight.Medium,
                letterSpacing = 2.sp
            ),
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Phone,
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(
                onDone = { onDone() }
            ),
            singleLine = true,
            cursorBrush = SolidColor(SafarTheme.colors.primary),
            decorationBox = { innerTextField ->
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (value.isEmpty()) {
                        Text(
                            text = "5XX XXX XXXX",
                            style = SafarTheme.typography.bodyLarge,
                            color = SafarTheme.colors.onSurfaceVariant.copy(alpha = 0.5f),
                            letterSpacing = 2.sp
                        )
                    }
                    innerTextField()
                }
            }
        )
    }
}

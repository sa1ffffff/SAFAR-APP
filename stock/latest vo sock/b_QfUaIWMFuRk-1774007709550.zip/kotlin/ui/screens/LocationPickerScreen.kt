package com.safar.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.*
import com.safar.ui.theme.SafarTheme
import kotlinx.coroutines.delay

/**
 * LocationPickerScreen - Enterprise-grade location selection screen
 * 
 * Design Philosophy:
 * - Uber-inspired full-screen map with bottom sheet interface
 * - Smart search with recent locations and suggestions
 * - Smooth animations and haptic feedback patterns
 * - Clear visual hierarchy for location selection
 */

data class LocationSuggestion(
    val id: String,
    val name: String,
    val address: String,
    val latLng: LatLng,
    val type: LocationType = LocationType.PLACE
)

enum class LocationType {
    HOME,
    WORK,
    RECENT,
    PLACE
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocationPickerScreen(
    onNavigateBack: () -> Unit,
    onLocationSelected: (LocationSuggestion) -> Unit,
    initialLocation: LatLng = LatLng(24.7136, 46.6753), // Riyadh default
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var isSearchFocused by remember { mutableStateOf(false) }
    var selectedLocation by remember { mutableStateOf<LocationSuggestion?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var showBottomSheet by remember { mutableStateOf(true) }
    
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(initialLocation, 15f)
    }
    
    val focusRequester = remember { FocusRequester() }
    
    // Sample locations data
    val savedLocations = remember {
        listOf(
            LocationSuggestion(
                id = "home",
                name = "Home",
                address = "123 Al Olaya Street, Riyadh",
                latLng = LatLng(24.7136, 46.6753),
                type = LocationType.HOME
            ),
            LocationSuggestion(
                id = "work",
                name = "Work",
                address = "King Fahd Road, Business District",
                latLng = LatLng(24.7256, 46.6402),
                type = LocationType.WORK
            )
        )
    }
    
    val recentLocations = remember {
        listOf(
            LocationSuggestion(
                id = "recent1",
                name = "Kingdom Centre",
                address = "King Fahd Road, Al Olaya, Riyadh",
                latLng = LatLng(24.7113, 46.6744),
                type = LocationType.RECENT
            ),
            LocationSuggestion(
                id = "recent2",
                name = "Riyadh Gallery Mall",
                address = "King Fahd Road, Riyadh",
                latLng = LatLng(24.6909, 46.6729),
                type = LocationType.RECENT
            ),
            LocationSuggestion(
                id = "recent3",
                name = "King Khalid International Airport",
                address = "Airport Road, Riyadh",
                latLng = LatLng(24.9597, 46.6989),
                type = LocationType.RECENT
            )
        )
    }
    
    val searchResults = remember(searchQuery) {
        if (searchQuery.length >= 2) {
            (savedLocations + recentLocations).filter {
                it.name.contains(searchQuery, ignoreCase = true) ||
                it.address.contains(searchQuery, ignoreCase = true)
            }
        } else {
            emptyList()
        }
    }
    
    Box(modifier = modifier.fillMaxSize()) {
        // Map Layer
        GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = cameraPositionState,
            properties = MapProperties(
                mapType = MapType.NORMAL,
                isMyLocationEnabled = false
            ),
            uiSettings = MapUiSettings(
                zoomControlsEnabled = false,
                myLocationButtonEnabled = false,
                compassEnabled = false
            ),
            onMapClick = { latLng ->
                selectedLocation = LocationSuggestion(
                    id = "selected",
                    name = "Selected Location",
                    address = "Lat: ${latLng.latitude}, Lng: ${latLng.longitude}",
                    latLng = latLng,
                    type = LocationType.PLACE
                )
            }
        ) {
            // Selected location marker
            selectedLocation?.let { location ->
                Marker(
                    state = MarkerState(position = location.latLng),
                    title = location.name
                )
            }
        }
        
        // Center pin indicator (always visible)
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Place,
                contentDescription = "Pin location",
                tint = SafarTheme.colors.primary,
                modifier = Modifier
                    .size(48.dp)
                    .offset(y = (-24).dp)
            )
            
            // Shadow dot
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(
                        Color.Black.copy(alpha = 0.3f),
                        CircleShape
                    )
            )
        }
        
        // Top Search Bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                color = SafarTheme.colors.surfaceElevated,
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Go back",
                            tint = SafarTheme.colors.onSurface
                        )
                    }
                    
                    BasicTextField(
                        value = searchQuery,
                        onValueChange = { 
                            searchQuery = it
                            isSearchFocused = it.isNotEmpty()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .focusRequester(focusRequester),
                        textStyle = SafarTheme.typography.bodyLarge.copy(
                            color = SafarTheme.colors.onSurface
                        ),
                        singleLine = true,
                        cursorBrush = SolidColor(SafarTheme.colors.primary),
                        decorationBox = { innerTextField ->
                            Box(
                                modifier = Modifier.padding(vertical = 12.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                if (searchQuery.isEmpty()) {
                                    Text(
                                        text = "Search for a location",
                                        style = SafarTheme.typography.bodyLarge,
                                        color = SafarTheme.colors.onSurfaceVariant
                                    )
                                }
                                innerTextField()
                            }
                        }
                    )
                    
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Clear search",
                                tint = SafarTheme.colors.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            
            // Search Results Dropdown
            AnimatedVisibility(
                visible = searchResults.isNotEmpty(),
                enter = fadeIn() + slideInVertically(),
                exit = fadeOut() + slideOutVertically()
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = SafarTheme.colors.surfaceElevated,
                    shadowElevation = 8.dp
                ) {
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 300.dp)
                    ) {
                        items(searchResults) { suggestion ->
                            LocationSuggestionItem(
                                suggestion = suggestion,
                                onClick = {
                                    selectedLocation = suggestion
                                    searchQuery = suggestion.name
                                    isSearchFocused = false
                                    onLocationSelected(suggestion)
                                }
                            )
                        }
                    }
                }
            }
        }
        
        // My Location FAB
        FloatingActionButton(
            onClick = {
                // Request current location
            },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 180.dp),
            containerColor = SafarTheme.colors.surfaceElevated,
            contentColor = SafarTheme.colors.onSurface,
            shape = CircleShape,
            elevation = FloatingActionButtonDefaults.elevation(
                defaultElevation = 4.dp
            )
        ) {
            Icon(
                imageVector = Icons.Default.MyLocation,
                contentDescription = "My location"
            )
        }
        
        // Bottom Sheet
        AnimatedVisibility(
            visible = showBottomSheet && !isSearchFocused,
            enter = slideInVertically { it },
            exit = slideOutVertically { it },
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                color = SafarTheme.colors.surfaceElevated,
                shadowElevation = 16.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    // Handle
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .width(40.dp)
                            .height(4.dp)
                            .background(
                                SafarTheme.colors.onSurfaceVariant.copy(alpha = 0.3f),
                                RoundedCornerShape(2.dp)
                            )
                    )
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    // Saved Locations
                    if (savedLocations.isNotEmpty()) {
                        Text(
                            text = "Saved Places",
                            style = SafarTheme.typography.titleMedium,
                            color = SafarTheme.colors.onSurface,
                            fontWeight = FontWeight.SemiBold
                        )
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            savedLocations.forEach { location ->
                                SavedLocationChip(
                                    location = location,
                                    onClick = {
                                        selectedLocation = location
                                        onLocationSelected(location)
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(20.dp))
                    }
                    
                    // Recent Locations
                    if (recentLocations.isNotEmpty()) {
                        Text(
                            text = "Recent",
                            style = SafarTheme.typography.titleMedium,
                            color = SafarTheme.colors.onSurface,
                            fontWeight = FontWeight.SemiBold
                        )
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        recentLocations.take(3).forEach { location ->
                            RecentLocationItem(
                                location = location,
                                onClick = {
                                    selectedLocation = location
                                    onLocationSelected(location)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Location suggestion item in search results
 */
@Composable
private fun LocationSuggestionItem(
    suggestion: LocationSuggestion,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(
                    SafarTheme.colors.surface,
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = getLocationIcon(suggestion.type),
                contentDescription = null,
                tint = SafarTheme.colors.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
        }
        
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = suggestion.name,
                style = SafarTheme.typography.bodyLarge,
                color = SafarTheme.colors.onSurface,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = suggestion.address,
                style = SafarTheme.typography.bodySmall,
                color = SafarTheme.colors.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * Saved location chip (Home, Work)
 */
@Composable
private fun SavedLocationChip(
    location: LocationSuggestion,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = SafarTheme.colors.surface,
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = SafarTheme.colors.border
        )
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = getLocationIcon(location.type),
                contentDescription = null,
                tint = SafarTheme.colors.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = location.name,
                style = SafarTheme.typography.bodyMedium,
                color = SafarTheme.colors.onSurface,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

/**
 * Recent location item
 */
@Composable
private fun RecentLocationItem(
    location: LocationSuggestion,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.History,
            contentDescription = null,
            tint = SafarTheme.colors.onSurfaceVariant,
            modifier = Modifier.size(24.dp)
        )
        
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = location.name,
                style = SafarTheme.typography.bodyLarge,
                color = SafarTheme.colors.onSurface,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = location.address,
                style = SafarTheme.typography.bodySmall,
                color = SafarTheme.colors.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * Get appropriate icon for location type
 */
private fun getLocationIcon(type: LocationType): ImageVector {
    return when (type) {
        LocationType.HOME -> Icons.Default.Home
        LocationType.WORK -> Icons.Default.Work
        LocationType.RECENT -> Icons.Default.History
        LocationType.PLACE -> Icons.Default.Place
    }
}

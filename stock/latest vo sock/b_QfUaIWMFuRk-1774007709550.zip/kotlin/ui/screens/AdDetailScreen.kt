package com.safar.app.views.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.safar.app.views.ui.theme.*

// ─── Data Models ─────────────────────────────────────────────────────────────
data class AdDetailUiState(
    val origin: String = "",
    val destination: String = "",
    val departureTime: String = "",
    val seats: String = "",
    val postedBy: String = "",
    val vehicle: String = "",
    val status: String = "Open",
    val notes: String = "",
    val price: String = "",
    val isOwner: Boolean = false,
    val isLoading: Boolean = false,
    val hasRequested: Boolean = false,
    val joinRequests: List<JoinRequestUiModel> = emptyList()
)

data class JoinRequestUiModel(
    val id: String,
    val userName: String,
    val userPhone: String = "",
    val status: String = "Pending"
)

/**
 * SAFAR AD DETAIL SCREEN
 * Enterprise-level ride detail view with Uber-inspired design
 * 
 * Features:
 * - Clean route visualization
 * - Detailed ride information
 * - Join request management
 * - Owner actions (mark filled, delete)
 * - Smooth animations
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdDetailScreen(
    uiState: AdDetailUiState = AdDetailUiState(),
    onBack: () -> Unit = {},
    onMarkFilled: () -> Unit = {},
    onDeleteAd: () -> Unit = {},
    onSendRequest: () -> Unit = {},
    onAcceptRequest: (String) -> Unit = {},
    onRejectRequest: (String) -> Unit = {},
    onContactDriver: () -> Unit = {},
    onShareRide: () -> Unit = {}
) {
    SafarTheme(darkTheme = false) {
        Scaffold(
            containerColor = SafarBg,
            topBar = {
                AdDetailTopBar(
                    onBack = onBack,
                    onShare = onShareRide
                )
            }
        ) { innerPadding ->
            if (uiState.isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(
                            color = SafarGreen,
                            modifier = Modifier.size(40.dp),
                            strokeWidth = 3.dp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            "Loading ride details...",
                            color = SafarTextMuted,
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Route Card
                    item {
                        RouteCard(
                            origin = uiState.origin,
                            destination = uiState.destination
                        )
                    }

                    // Info Card
                    item {
                        InfoCard(
                            departureTime = uiState.departureTime,
                            seats = uiState.seats,
                            postedBy = uiState.postedBy,
                            vehicle = uiState.vehicle,
                            status = uiState.status,
                            price = uiState.price
                        )
                    }

                    // Notes Card
                    if (uiState.notes.isNotBlank()) {
                        item {
                            NotesCard(notes = uiState.notes)
                        }
                    }

                    // Owner Actions
                    if (uiState.isOwner) {
                        item {
                            OwnerActionsCard(
                                onMarkFilled = onMarkFilled,
                                onDeleteAd = onDeleteAd
                            )
                        }
                    }

                    // Requester Actions
                    if (!uiState.isOwner) {
                        item {
                            RequesterActionsCard(
                                hasRequested = uiState.hasRequested,
                                onSendRequest = onSendRequest,
                                onContactDriver = onContactDriver
                            )
                        }
                    }

                    // Join Requests Section (Owner only)
                    if (uiState.isOwner && uiState.joinRequests.isNotEmpty()) {
                        item {
                            Text(
                                text = "JOIN REQUESTS",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = SafarTextMuted,
                                letterSpacing = 1.5.sp,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                        
                        items(
                            items = uiState.joinRequests,
                            key = { it.id }
                        ) { request ->
                            JoinRequestCard(
                                request = request,
                                onAccept = { onAcceptRequest(request.id) },
                                onReject = { onRejectRequest(request.id) }
                            )
                        }
                    }

                    if (uiState.isOwner && uiState.joinRequests.isEmpty()) {
                        item {
                            EmptyRequestsView()
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AdDetailTopBar(
    onBack: () -> Unit,
    onShare: () -> Unit
) {
    TopAppBar(
        title = {
            Text(
                "Ride Detail",
                fontWeight = FontWeight.Bold,
                color = SafarTextDark
            )
        },
        navigationIcon = {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.Rounded.ArrowBackIosNew,
                    contentDescription = "Back",
                    tint = SafarTextDark
                )
            }
        },
        actions = {
            IconButton(onClick = onShare) {
                Icon(
                    imageVector = Icons.Rounded.Share,
                    contentDescription = "Share",
                    tint = SafarTextDark
                )
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = SafarWhite
        )
    )
}

@Composable
private fun RouteCard(origin: String, destination: String) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SafarWhite),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            // Origin
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(SafarSuccess)
                )
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "PICKUP",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SafarTextMuted,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = origin,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 16.sp,
                        color = SafarTextDark
                    )
                }
            }

            // Connector
            Box(
                modifier = Modifier
                    .padding(start = 5.dp, top = 6.dp, bottom = 6.dp)
                    .width(2.dp)
                    .height(24.dp)
                    .background(SafarDividerLight)
            )

            // Destination
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(SafarGreen)
                )
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "DESTINATION",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SafarTextMuted,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = destination,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 16.sp,
                        color = SafarTextDark
                    )
                }
            }
        }
    }
}

@Composable
private fun InfoCard(
    departureTime: String,
    seats: String,
    postedBy: String,
    vehicle: String,
    status: String,
    price: String
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SafarWhite),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            // Status chip
            val isOpen = status.equals("Open", ignoreCase = true)
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (isOpen) StatusOpen.copy(alpha = 0.12f)
                else StatusFilled.copy(alpha = 0.12f)
            ) {
                Text(
                    text = status,
                    color = if (isOpen) StatusOpen else StatusFilled,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            InfoRow(icon = Icons.Rounded.Schedule, label = "Departure", text = departureTime)
            HorizontalDivider(color = SafarDividerLight, modifier = Modifier.padding(vertical = 12.dp))
            InfoRow(icon = Icons.Rounded.EventSeat, label = "Seats", text = seats)
            HorizontalDivider(color = SafarDividerLight, modifier = Modifier.padding(vertical = 12.dp))
            InfoRow(icon = Icons.Rounded.Person, label = "Posted by", text = postedBy)

            if (vehicle.isNotBlank()) {
                HorizontalDivider(color = SafarDividerLight, modifier = Modifier.padding(vertical = 12.dp))
                InfoRow(icon = Icons.Rounded.DirectionsCar, label = "Vehicle", text = vehicle)
            }

            if (price.isNotBlank()) {
                HorizontalDivider(color = SafarDividerLight, modifier = Modifier.padding(vertical = 12.dp))
                InfoRow(icon = Icons.Rounded.AttachMoney, label = "Price per seat", text = price, highlight = true)
            }
        }
    }
}

@Composable
private fun InfoRow(
    icon: ImageVector,
    label: String,
    text: String,
    highlight: Boolean = false
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(SafarGreen.copy(alpha = 0.08f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = SafarGreen,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                fontSize = 11.sp,
                color = SafarTextMuted
            )
            Text(
                text = text,
                color = if (highlight) SafarGreen else SafarTextDark,
                fontSize = 15.sp,
                fontWeight = if (highlight) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}

@Composable
private fun NotesCard(notes: String) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SafarWhite),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = Icons.Rounded.Notes,
                contentDescription = null,
                tint = SafarGreen,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(
                    "NOTES",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = SafarTextMuted,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    notes,
                    color = SafarTextMuted,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )
            }
        }
    }
}

@Composable
private fun OwnerActionsCard(
    onMarkFilled: () -> Unit,
    onDeleteAd: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SafarWhite),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                "MANAGE RIDE",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = SafarTextMuted,
                letterSpacing = 1.sp
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onMarkFilled,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.5.dp, SafarGreen),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = SafarGreen
                    )
                ) {
                    Icon(
                        Icons.Rounded.CheckCircle,
                        null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Mark Filled", fontWeight = FontWeight.SemiBold)
                }

                Button(
                    onClick = onDeleteAd,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SafarError,
                        contentColor = Color.White
                    )
                ) {
                    Icon(
                        Icons.Rounded.DeleteOutline,
                        null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Delete", fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun RequesterActionsCard(
    hasRequested: Boolean,
    onSendRequest: () -> Unit,
    onContactDriver: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (!hasRequested) {
            Button(
                onClick = onSendRequest,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = SafarGreen,
                    contentColor = SafarBlack
                )
            ) {
                Icon(
                    Icons.Rounded.PersonAdd,
                    null,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    "Request to Join",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        } else {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = SafarGreen.copy(alpha = 0.12f)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        Icons.Rounded.CheckCircle,
                        null,
                        tint = SafarGreen,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "Request Sent",
                        color = SafarGreen,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp
                    )
                }
            }
        }

        OutlinedButton(
            onClick = onContactDriver,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.5.dp, SafarDividerLight),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = SafarTextDark
            )
        ) {
            Icon(
                Icons.Rounded.Chat,
                null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("Contact Driver", fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun JoinRequestCard(
    request: JoinRequestUiModel,
    onAccept: () -> Unit,
    onReject: () -> Unit
) {
    val isPending = request.status == "Pending"
    val isAccepted = request.status == "Accepted"

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SafarWhite),
        elevation = CardDefaults.cardElevation(1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Avatar
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(SafarGreen.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = request.userName.firstOrNull()?.uppercaseChar()?.toString() ?: "?",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = SafarGreen
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    request.userName,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    color = SafarTextDark
                )
                if (request.userPhone.isNotBlank()) {
                    Text(
                        request.userPhone,
                        color = SafarTextMuted,
                        fontSize = 12.sp
                    )
                }
            }

            if (isPending) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(
                        onClick = onAccept,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(StatusOpen.copy(alpha = 0.12f))
                    ) {
                        Icon(
                            Icons.Rounded.Check,
                            "Accept",
                            tint = StatusOpen
                        )
                    }
                    IconButton(
                        onClick = onReject,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(StatusFilled.copy(alpha = 0.12f))
                    ) {
                        Icon(
                            Icons.Rounded.Close,
                            "Reject",
                            tint = StatusFilled
                        )
                    }
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isAccepted) StatusOpen.copy(alpha = 0.12f)
                    else StatusFilled.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = request.status,
                        color = if (isAccepted) StatusOpen else StatusFilled,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyRequestsView() {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SafarWhite),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                Icons.Rounded.PersonAdd,
                null,
                tint = SafarTextMuted.copy(alpha = 0.3f),
                modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                "No requests yet",
                fontWeight = FontWeight.SemiBold,
                color = SafarTextMuted
            )
            Text(
                "Requests to join will appear here",
                fontSize = 13.sp,
                color = SafarTextLight
            )
        }
    }
}

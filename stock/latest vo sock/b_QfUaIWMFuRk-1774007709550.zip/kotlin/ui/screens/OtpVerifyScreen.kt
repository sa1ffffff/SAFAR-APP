package com.safar.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.safar.ui.theme.SafarTheme
import kotlinx.coroutines.delay

/**
 * OtpVerifyScreen - Enterprise-grade OTP verification screen
 * 
 * Design Philosophy:
 * - Uber-inspired minimalist dark interface
 * - Individual digit input boxes for clear visual feedback
 * - Auto-advance functionality for seamless input
 * - Countdown timer for resend functionality
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OtpVerifyScreen(
    phoneNumber: String,
    onNavigateBack: () -> Unit,
    onVerifyOtp: (String) -> Unit,
    onResendOtp: () -> Unit,
    modifier: Modifier = Modifier
) {
    var otpValue by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var isVerified by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showContent by remember { mutableStateOf(false) }
    var resendCountdown by remember { mutableIntStateOf(30) }
    var canResend by remember { mutableStateOf(false) }
    
    val focusRequester = remember { FocusRequester() }
    val keyboardController = LocalSoftwareKeyboardController.current
    
    // Entrance animation
    LaunchedEffect(Unit) {
        delay(100)
        showContent = true
        delay(300)
        focusRequester.requestFocus()
    }
    
    // Resend countdown timer
    LaunchedEffect(canResend) {
        if (!canResend) {
            while (resendCountdown > 0) {
                delay(1000)
                resendCountdown--
            }
            canResend = true
        }
    }
    
    // Auto-verify when OTP is complete
    LaunchedEffect(otpValue) {
        if (otpValue.length == 6) {
            keyboardController?.hide()
            isLoading = true
            delay(1500) // Simulate verification
            onVerifyOtp(otpValue)
        }
    }
    
    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = SafarTheme.colors.background,
        topBar = {
            TopAppBar(
                title = { },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier
                            .padding(8.dp)
                            .size(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Go back",
                            tint = SafarTheme.colors.onBackground
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SafarTheme.colors.background
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Spacer(modifier = Modifier.height(24.dp))
            
            // Header Section
            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(tween(400)) + slideInVertically(tween(400)) { -it / 2 }
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Enter verification code",
                        style = SafarTheme.typography.headlineLarge,
                        color = SafarTheme.colors.onBackground,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Text(
                        text = "We sent a 6-digit code to",
                        style = SafarTheme.typography.bodyLarge,
                        color = SafarTheme.colors.onSurfaceVariant
                    )
                    
                    Text(
                        text = formatPhoneNumber(phoneNumber),
                        style = SafarTheme.typography.bodyLarge,
                        color = SafarTheme.colors.onBackground,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // OTP Input Section
            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(tween(400, delayMillis = 150)) + 
                        slideInVertically(tween(400, delayMillis = 150)) { it / 2 }
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // OTP Input Boxes
                    OtpInputField(
                        otpValue = otpValue,
                        onOtpChange = { 
                            if (it.length <= 6 && it.all { char -> char.isDigit() }) {
                                otpValue = it
                                errorMessage = null
                            }
                        },
                        isError = errorMessage != null,
                        isVerified = isVerified,
                        focusRequester = focusRequester,
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    // Error Message
                    errorMessage?.let { error ->
                        Text(
                            text = error,
                            style = SafarTheme.typography.bodySmall,
                            color = SafarTheme.colors.error,
                            textAlign = TextAlign.Center
                        )
                    }
                    
                    // Loading Indicator
                    if (isLoading && !isVerified) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = SafarTheme.colors.primary,
                                strokeWidth = 2.dp
                            )
                            Text(
                                text = "Verifying...",
                                style = SafarTheme.typography.bodyMedium,
                                color = SafarTheme.colors.onSurfaceVariant
                            )
                        }
                    }
                    
                    // Verified State
                    if (isVerified) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Verified",
                                tint = SafarTheme.colors.success,
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = "Verified successfully",
                                style = SafarTheme.typography.bodyMedium,
                                color = SafarTheme.colors.success,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
            
            Spacer(modifier = Modifier.weight(1f))
            
            // Resend Section
            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(tween(400, delayMillis = 300)) + 
                        slideInVertically(tween(400, delayMillis = 300)) { it }
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "Didn't receive the code?",
                        style = SafarTheme.typography.bodyMedium,
                        color = SafarTheme.colors.onSurfaceVariant
                    )
                    
                    if (canResend) {
                        TextButton(
                            onClick = {
                                canResend = false
                                resendCountdown = 30
                                onResendOtp()
                            }
                        ) {
                            Text(
                                text = "Resend Code",
                                style = SafarTheme.typography.titleMedium,
                                color = SafarTheme.colors.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    } else {
                        Text(
                            text = "Resend in ${resendCountdown}s",
                            style = SafarTheme.typography.bodyMedium,
                            color = SafarTheme.colors.onSurfaceVariant
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

/**
 * OTP input field with individual digit boxes
 */
@Composable
private fun OtpInputField(
    otpValue: String,
    onOtpChange: (String) -> Unit,
    isError: Boolean,
    isVerified: Boolean,
    focusRequester: FocusRequester,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier) {
        // Hidden text field for actual input
        BasicTextField(
            value = otpValue,
            onValueChange = onOtpChange,
            modifier = Modifier
                .fillMaxWidth()
                .focusRequester(focusRequester),
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.NumberPassword,
                imeAction = ImeAction.Done
            ),
            singleLine = true,
            decorationBox = { }
        )
        
        // Visual OTP boxes
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            repeat(6) { index ->
                val char = otpValue.getOrNull(index)
                val isFilled = char != null
                val isCurrentIndex = index == otpValue.length
                
                val borderColor = when {
                    isVerified -> SafarTheme.colors.success
                    isError -> SafarTheme.colors.error
                    isCurrentIndex -> SafarTheme.colors.primary
                    isFilled -> SafarTheme.colors.primary.copy(alpha = 0.5f)
                    else -> SafarTheme.colors.border
                }
                
                val backgroundColor = when {
                    isVerified -> SafarTheme.colors.success.copy(alpha = 0.1f)
                    isFilled -> SafarTheme.colors.surfaceElevated
                    else -> SafarTheme.colors.surface
                }
                
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .aspectRatio(0.8f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(backgroundColor)
                        .border(
                            width = if (isCurrentIndex || isFilled) 2.dp else 1.dp,
                            color = borderColor,
                            shape = RoundedCornerShape(12.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isFilled) {
                        Text(
                            text = char.toString(),
                            style = SafarTheme.typography.headlineLarge,
                            color = SafarTheme.colors.onSurface,
                            fontWeight = FontWeight.Bold
                        )
                    } else if (isCurrentIndex) {
                        // Blinking cursor
                        Box(
                            modifier = Modifier
                                .width(2.dp)
                                .height(28.dp)
                                .background(
                                    SafarTheme.colors.primary,
                                    RoundedCornerShape(1.dp)
                                )
                        )
                    }
                }
            }
        }
    }
}

/**
 * Format phone number for display
 */
private fun formatPhoneNumber(phone: String): String {
    return if (phone.length > 4) {
        val code = phone.take(4)
        val number = phone.drop(4)
        "$code ${number.chunked(3).joinToString(" ")}"
    } else {
        phone
    }
}

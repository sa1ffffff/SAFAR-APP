package com.safar.app.views.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.safar.app.views.ui.theme.*

// ─── Data / State ─────────────────────────────────────────────────────────────
enum class LoginTab { PHONE, EMAIL }
enum class EmailMode { LOGIN, REGISTER }

data class LoginUiState(
    val selectedTab: LoginTab = LoginTab.PHONE,
    val emailMode: EmailMode = EmailMode.LOGIN,
    val phone: String = "",
    val countryCode: String = "+92",
    val name: String = "",
    val email: String = "",
    val password: String = "",
    val isLoading: Boolean = false,
    val showPassword: Boolean = false,
    val error: String? = null
)

/**
 * SAFAR LOGIN SCREEN
 * Enterprise-level authentication UI with Uber-inspired design
 * 
 * Features:
 * - Phone & Email authentication tabs
 * - Smooth animated transitions
 * - Premium input field styling
 * - Google OAuth integration ready
 * - Accessible and responsive layout
 */
@Composable
fun LoginScreen(
    uiState: LoginUiState = LoginUiState(),
    onTabSelected: (LoginTab) -> Unit = {},
    onPhoneChanged: (String) -> Unit = {},
    onEmailChanged: (String) -> Unit = {},
    onPasswordChanged: (String) -> Unit = {},
    onNameChanged: (String) -> Unit = {},
    onContinuePhone: () -> Unit = {},
    onEmailAction: () -> Unit = {},
    onToggleEmailMode: () -> Unit = {},
    onForgotPassword: () -> Unit = {},
    onGoogleSignIn: () -> Unit = {},
    onTogglePassword: () -> Unit = {}
) {
    SafarTheme(darkTheme = true) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(SafarBlack)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(64.dp))

            // Logo Section
            LogoSection()

            Spacer(modifier = Modifier.height(48.dp))

            // Tab Row
            LoginTabRow(
                selected = uiState.selectedTab,
                onSelected = onTabSelected
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Error Message
            AnimatedVisibility(
                visible = uiState.error != null,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                uiState.error?.let { error ->
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = SafarError.copy(alpha = 0.12f)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ErrorOutline,
                                contentDescription = null,
                                tint = SafarError,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = error,
                                color = SafarError,
                                fontSize = 13.sp
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }

            // Tab Content
            AnimatedContent(
                targetState = uiState.selectedTab,
                transitionSpec = {
                    if (targetState == LoginTab.EMAIL) {
                        slideInHorizontally { it } + fadeIn() togetherWith
                                slideOutHorizontally { -it } + fadeOut()
                    } else {
                        slideInHorizontally { -it } + fadeIn() togetherWith
                                slideOutHorizontally { it } + fadeOut()
                    }
                },
                label = "tabContent"
            ) { tab ->
                when (tab) {
                    LoginTab.PHONE -> PhoneTabContent(
                        phone = uiState.phone,
                        countryCode = uiState.countryCode,
                        isLoading = uiState.isLoading,
                        onPhoneChanged = onPhoneChanged,
                        onContinue = onContinuePhone
                    )
                    LoginTab.EMAIL -> EmailTabContent(
                        mode = uiState.emailMode,
                        name = uiState.name,
                        email = uiState.email,
                        password = uiState.password,
                        showPassword = uiState.showPassword,
                        isLoading = uiState.isLoading,
                        onNameChanged = onNameChanged,
                        onEmailChanged = onEmailChanged,
                        onPasswordChanged = onPasswordChanged,
                        onEmailAction = onEmailAction,
                        onToggleEmailMode = onToggleEmailMode,
                        onForgotPassword = onForgotPassword,
                        onTogglePassword = onTogglePassword
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // OR Divider
            OrDivider()

            Spacer(modifier = Modifier.height(24.dp))

            // Social Sign In
            SocialSignInButton(
                onClick = onGoogleSignIn,
                isLoading = uiState.isLoading
            )

            // Loading Indicator
            AnimatedVisibility(
                visible = uiState.isLoading,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Spacer(modifier = Modifier.height(24.dp))
                CircularProgressIndicator(
                    color = SafarGreen,
                    modifier = Modifier.size(28.dp),
                    strokeWidth = 2.5.dp
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Terms Text
            Text(
                text = "By continuing, you agree to our Terms of Service and Privacy Policy",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = SafarTextTertiary,
                    fontSize = 12.sp
                ),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
private fun LogoSection() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        // Logo Icon
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(SafarGreen.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.DirectionsCar,
                contentDescription = "Safar",
                tint = SafarGreen,
                modifier = Modifier.size(40.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // App Name
        Text(
            text = "SAFAR",
            style = MaterialTheme.typography.displaySmall.copy(
                fontWeight = FontWeight.Black,
                letterSpacing = 4.sp,
                color = SafarTextPrimary,
                fontSize = 36.sp
            )
        )

        Spacer(modifier = Modifier.height(4.dp))

        // Tagline
        Text(
            text = "Community Carpool, Made Easy",
            style = MaterialTheme.typography.bodyMedium.copy(
                color = SafarTextSecondary,
                fontWeight = FontWeight.Medium
            )
        )
    }
}

@Composable
private fun LoginTabRow(
    selected: LoginTab,
    onSelected: (LoginTab) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp),
        shape = RoundedCornerShape(14.dp),
        color = SafarDarkCard
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(4.dp)
        ) {
            LoginTab.entries.forEach { tab ->
                val isActive = tab == selected
                
                val backgroundColor by animateColorAsState(
                    targetValue = if (isActive) SafarGreen else Color.Transparent,
                    animationSpec = tween(200),
                    label = "tabBg"
                )
                
                val textColor by animateColorAsState(
                    targetValue = if (isActive) SafarBlack else SafarTextSecondary,
                    animationSpec = tween(200),
                    label = "tabText"
                )
                
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(10.dp))
                        .background(backgroundColor)
                        .clickable { onSelected(tab) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tab.name.lowercase().replaceFirstChar { it.uppercase() },
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = textColor
                    )
                }
            }
        }
    }
}

@Composable
private fun PhoneTabContent(
    phone: String,
    countryCode: String,
    isLoading: Boolean,
    onPhoneChanged: (String) -> Unit,
    onContinue: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        // Phone Input Container
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp),
            shape = RoundedCornerShape(14.dp),
            color = SafarDarkCard
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Country Code
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = SafarDarkSurface
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = countryCode,
                            color = SafarGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Icon(
                            imageVector = Icons.Rounded.KeyboardArrowDown,
                            contentDescription = null,
                            tint = SafarTextTertiary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Phone Input
                OutlinedTextField(
                    value = phone,
                    onValueChange = onPhoneChanged,
                    placeholder = {
                        Text("Phone number", color = SafarTextTertiary)
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedTextColor = SafarTextPrimary,
                        unfocusedTextColor = SafarTextPrimary,
                        cursorColor = SafarGreen
                    ),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Continue Button
        Button(
            onClick = onContinue,
            enabled = phone.length >= 7 && !isLoading,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = SafarGreen,
                contentColor = SafarBlack,
                disabledContainerColor = SafarGreen.copy(alpha = 0.3f),
                disabledContentColor = SafarBlack.copy(alpha = 0.3f)
            )
        ) {
            Text(
                text = "Continue",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                imageVector = Icons.Rounded.ArrowForward,
                contentDescription = null,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Info Text
        Text(
            text = "We'll send you a 6-digit verification code via SMS",
            style = MaterialTheme.typography.bodySmall.copy(
                color = SafarTextTertiary
            ),
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun EmailTabContent(
    mode: EmailMode,
    name: String,
    email: String,
    password: String,
    showPassword: Boolean,
    isLoading: Boolean,
    onNameChanged: (String) -> Unit,
    onEmailChanged: (String) -> Unit,
    onPasswordChanged: (String) -> Unit,
    onEmailAction: () -> Unit,
    onToggleEmailMode: () -> Unit,
    onForgotPassword: () -> Unit,
    onTogglePassword: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        // Name Field (Register only)
        AnimatedVisibility(
            visible = mode == EmailMode.REGISTER,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column {
                SafarTextField(
                    value = name,
                    onValueChange = onNameChanged,
                    placeholder = "Full Name",
                    leadingIcon = Icons.Rounded.Person,
                    keyboardType = KeyboardType.Text
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
        }

        // Email Field
        SafarTextField(
            value = email,
            onValueChange = onEmailChanged,
            placeholder = "Email address",
            leadingIcon = Icons.Rounded.Email,
            keyboardType = KeyboardType.Email
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Password Field
        SafarTextField(
            value = password,
            onValueChange = onPasswordChanged,
            placeholder = "Password",
            leadingIcon = Icons.Rounded.Lock,
            keyboardType = KeyboardType.Password,
            isPassword = true,
            showPassword = showPassword,
            onTogglePassword = onTogglePassword
        )

        // Forgot Password
        AnimatedVisibility(visible = mode == EmailMode.LOGIN) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                Text(
                    text = "Forgot Password?",
                    color = SafarGreen,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { onForgotPassword() }
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Submit Button
        Button(
            onClick = onEmailAction,
            enabled = email.isNotBlank() && password.length >= 6 && !isLoading,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = SafarGreen,
                contentColor = SafarBlack,
                disabledContainerColor = SafarGreen.copy(alpha = 0.3f),
                disabledContentColor = SafarBlack.copy(alpha = 0.3f)
            )
        ) {
            Text(
                text = if (mode == EmailMode.LOGIN) "Sign In" else "Create Account",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Toggle Mode
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = if (mode == EmailMode.LOGIN) "Don't have an account? " else "Already have an account? ",
                color = SafarTextSecondary,
                fontSize = 14.sp
            )
            Text(
                text = if (mode == EmailMode.LOGIN) "Sign Up" else "Sign In",
                color = SafarGreen,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable { onToggleEmailMode() }
            )
        }
    }
}

@Composable
fun SafarTextField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    leadingIcon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    keyboardType: KeyboardType = KeyboardType.Text,
    isPassword: Boolean = false,
    showPassword: Boolean = false,
    onTogglePassword: () -> Unit = {}
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        placeholder = { Text(placeholder, color = SafarTextTertiary) },
        leadingIcon = leadingIcon?.let {
            {
                Icon(
                    imageVector = it,
                    contentDescription = null,
                    tint = SafarTextTertiary,
                    modifier = Modifier.size(20.dp)
                )
            }
        },
        trailingIcon = if (isPassword) {
            {
                IconButton(onClick = onTogglePassword) {
                    Icon(
                        imageVector = if (showPassword) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                        contentDescription = if (showPassword) "Hide" else "Show",
                        tint = SafarTextTertiary
                    )
                }
            }
        } else null,
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        visualTransformation = if (isPassword && !showPassword) PasswordVisualTransformation() else VisualTransformation.None,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = SafarGreen,
            unfocusedBorderColor = SafarDivider,
            focusedContainerColor = SafarDarkCard,
            unfocusedContainerColor = SafarDarkCard,
            focusedTextColor = SafarTextPrimary,
            unfocusedTextColor = SafarTextPrimary,
            cursorColor = SafarGreen
        ),
        modifier = Modifier
            .fillMaxWidth()
            .height(58.dp)
    )
}

@Composable
private fun OrDivider() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        HorizontalDivider(
            modifier = Modifier.weight(1f),
            color = SafarDivider,
            thickness = 1.dp
        )
        Text(
            text = "OR",
            color = SafarTextTertiary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        HorizontalDivider(
            modifier = Modifier.weight(1f),
            color = SafarDivider,
            thickness = 1.dp
        )
    }
}

@Composable
private fun SocialSignInButton(
    onClick: () -> Unit,
    isLoading: Boolean
) {
    OutlinedButton(
        onClick = onClick,
        enabled = !isLoading,
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, SafarDivider),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = SafarDarkCard,
            contentColor = SafarTextPrimary
        )
    ) {
        Icon(
            imageVector = Icons.Rounded.Language,
            contentDescription = "Google",
            modifier = Modifier.size(22.dp),
            tint = Color(0xFFEA4335)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = "Continue with Google",
            fontWeight = FontWeight.SemiBold,
            fontSize = 15.sp
        )
    }
}

package com.safar.app.views.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// ══════════════════════════════════════════════════════════════════════════════
// SAFAR DESIGN SYSTEM - UBER-INSPIRED ENTERPRISE UI
// Premium ride-hailing color scheme matching Uber's visual identity
// ══════════════════════════════════════════════════════════════════════════════

// ─── PRIMARY BRAND COLORS ─────────────────────────────────────────────────────
// Uber's signature black and white with accent colors

val UberBlack = Color(0xFF000000)
val UberWhite = Color(0xFFFFFFFF)
val UberGreen = Color(0xFF276EF1)  // Uber's primary blue accent
val UberBlue = Color(0xFF276EF1)

// ─── DARK THEME PALETTE (Primary Mode - Uber Style) ───────────────────────────
val SafarBlack = Color(0xFF000000)
val SafarDarkSurface = Color(0xFF141414)
val SafarDarkCard = Color(0xFF1F1F1F)
val SafarDarkElevated = Color(0xFF282828)

// Text colors for dark theme
val SafarTextPrimary = Color(0xFFFFFFFF)
val SafarTextSecondary = Color(0xFFB3B3B3)
val SafarTextTertiary = Color(0xFF757575)
val SafarTextDisabled = Color(0xFF545454)

// Dividers and borders
val SafarDivider = Color(0xFF333333)
val SafarBorder = Color(0xFF404040)

// ─── LIGHT THEME PALETTE ──────────────────────────────────────────────────────
val SafarBg = Color(0xFFF6F6F6)
val SafarWhite = Color(0xFFFFFFFF)
val SafarLightSurface = Color(0xFFFFFFFF)
val SafarLightCard = Color(0xFFFFFFFF)
val SafarLightElevated = Color(0xFFFAFAFA)

// Text colors for light theme
val SafarTextDark = Color(0xFF000000)
val SafarTextMuted = Color(0xFF6B6B6B)
val SafarTextLight = Color(0xFF8F8F8F)
val SafarDividerLight = Color(0xFFE5E5E5)

// ─── ACCENT COLORS ────────────────────────────────────────────────────────────
// Uber-style accent palette

// Primary action color (Uber Green for CTAs)
val SafarGreen = Color(0xFF06C167)  // Uber Eats green - perfect for action buttons
val SafarGreenDark = Color(0xFF048A46)
val SafarGreenLight = Color(0xFF34D399)

// Alternative blue accent (Uber's other primary)
val SafarBlue = Color(0xFF276EF1)
val SafarBlueDark = Color(0xFF1A56C4)
val SafarBlueLight = Color(0xFF5B91F5)

// Legacy yellow (for backwards compatibility during transition)
val SafarYellow = Color(0xFF06C167)  // Mapped to green now
val SafarYellowDark = Color(0xFF048A46)
val SafarYellowLight = Color(0xFF34D399)

// ─── STATUS COLORS ────────────────────────────────────────────────────────────
val StatusOpen = Color(0xFF06C167)      // Green - Available
val StatusFilled = Color(0xFFE74C3C)    // Red - Full/Closed
val StatusPending = Color(0xFFF59E0B)   // Amber - Waiting
val StatusInProgress = Color(0xFF276EF1) // Blue - Active

// ─── SEMANTIC COLORS ──────────────────────────────────────────────────────────
val SafarSuccess = Color(0xFF06C167)
val SafarWarning = Color(0xFFF59E0B)
val SafarError = Color(0xFFE74C3C)
val SafarInfo = Color(0xFF276EF1)

// ─── UBER-STYLE COLOR OBJECT ──────────────────────────────────────────────────
object SafarColors {
    // Core
    val background = SafarBlack
    val surface = SafarDarkSurface
    val surfaceElevated = SafarDarkCard
    val surfaceHighest = SafarDarkElevated
    
    // Primary brand
    val primary = SafarGreen
    val primaryDark = SafarGreenDark
    val primaryLight = SafarGreenLight
    val onPrimary = SafarBlack
    
    // Secondary
    val secondary = SafarBlue
    val secondaryDark = SafarBlueDark
    val onSecondary = SafarWhite
    
    // Text
    val textPrimary = SafarTextPrimary
    val textSecondary = SafarTextSecondary
    val textTertiary = SafarTextTertiary
    val textDisabled = SafarTextDisabled
    
    // Utility
    val divider = SafarDivider
    val border = SafarBorder
    
    // Status
    val success = SafarSuccess
    val warning = SafarWarning
    val error = SafarError
    val info = SafarInfo
}

// ─── TYPOGRAPHY ───────────────────────────────────────────────────────────────
// Uber uses a clean, modern sans-serif (similar to SF Pro or their custom UberMove)

object SafarTypography {
    val displayLarge = TextStyle(
        fontWeight = FontWeight.ExtraBold,
        fontSize = 40.sp,
        lineHeight = 48.sp,
        letterSpacing = (-1).sp
    )
    
    val displayMedium = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 32.sp,
        lineHeight = 40.sp,
        letterSpacing = (-0.5).sp
    )
    
    val displaySmall = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        lineHeight = 36.sp
    )
    
    val headlineLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 24.sp,
        lineHeight = 32.sp
    )
    
    val headlineMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 20.sp,
        lineHeight = 28.sp
    )
    
    val headlineSmall = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp,
        lineHeight = 26.sp
    )
    
    val titleLarge = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 24.sp
    )
    
    val titleMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 20.sp
    )
    
    val bodyLarge = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp
    )
    
    val bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp
    )
    
    val bodySmall = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 16.sp
    )
    
    val labelLarge = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.5.sp
    )
    
    val labelMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.5.sp
    )
    
    val labelSmall = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 10.sp,
        lineHeight = 14.sp,
        letterSpacing = 0.5.sp
    )
    
    val button = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 15.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.25.sp
    )
    
    val caption = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 11.sp,
        lineHeight = 14.sp
    )
}

// ─── SPACING SYSTEM (8dp Grid) ────────────────────────────────────────────────
object SafarSpacing {
    val none = 0
    val xxs = 2   // 2dp
    val xs = 4    // 4dp
    val sm = 8    // 8dp
    val md = 12   // 12dp
    val lg = 16   // 16dp
    val xl = 20   // 20dp
    val xxl = 24  // 24dp
    val xxxl = 32 // 32dp
}

// ─── RADIUS SYSTEM ────────────────────────────────────────────────────────────
object SafarRadius {
    val none = 0    // 0dp
    val xs = 4      // 4dp
    val sm = 8      // 8dp
    val md = 12     // 12dp
    val lg = 16     // 16dp
    val xl = 20     // 20dp
    val xxl = 24    // 24dp
    val full = 999  // Pill/Circle
}

// ─── ELEVATION SYSTEM ─────────────────────────────────────────────────────────
object SafarElevation {
    val none = 0    // 0dp
    val xs = 1      // 1dp
    val sm = 2      // 2dp
    val md = 4      // 4dp
    val lg = 8      // 8dp
    val xl = 12     // 12dp
    val xxl = 16    // 16dp
}

// ─── DARK THEME COLOR SCHEME ──────────────────────────────────────────────────
private val DarkColorScheme = darkColorScheme(
    primary = SafarGreen,
    onPrimary = SafarBlack,
    primaryContainer = SafarGreenDark,
    onPrimaryContainer = SafarWhite,
    secondary = SafarBlue,
    onSecondary = SafarWhite,
    secondaryContainer = SafarBlueDark,
    onSecondaryContainer = SafarWhite,
    tertiary = SafarTextSecondary,
    onTertiary = SafarBlack,
    background = SafarBlack,
    onBackground = SafarTextPrimary,
    surface = SafarDarkSurface,
    onSurface = SafarTextPrimary,
    surfaceVariant = SafarDarkCard,
    onSurfaceVariant = SafarTextSecondary,
    error = SafarError,
    onError = SafarWhite,
    outline = SafarDivider,
    outlineVariant = SafarBorder
)

// ─── LIGHT THEME COLOR SCHEME ─────────────────────────────────────────────────
private val LightColorScheme = lightColorScheme(
    primary = SafarGreen,
    onPrimary = SafarWhite,
    primaryContainer = SafarGreenLight,
    onPrimaryContainer = SafarBlack,
    secondary = SafarBlue,
    onSecondary = SafarWhite,
    secondaryContainer = SafarBlueLight,
    onSecondaryContainer = SafarBlack,
    tertiary = SafarTextMuted,
    onTertiary = SafarWhite,
    background = SafarBg,
    onBackground = SafarTextDark,
    surface = SafarWhite,
    onSurface = SafarTextDark,
    surfaceVariant = SafarLightElevated,
    onSurfaceVariant = SafarTextMuted,
    error = SafarError,
    onError = SafarWhite,
    outline = SafarDividerLight,
    outlineVariant = SafarDividerLight
)

// ─── THEME COMPOSABLE ─────────────────────────────────────────────────────────
// ─── THEME COLORS ACCESSOR ────────────────────────────────────────────────────
// Provides convenient access to theme colors throughout the app

data class SafarThemeColors(
    val background: Color,
    val surface: Color,
    val surfaceElevated: Color,
    val surfaceHighest: Color,
    val primary: Color,
    val primaryDark: Color,
    val primaryLight: Color,
    val onPrimary: Color,
    val secondary: Color,
    val onSecondary: Color,
    val onBackground: Color,
    val onSurface: Color,
    val onSurfaceVariant: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textTertiary: Color,
    val divider: Color,
    val border: Color,
    val success: Color,
    val warning: Color,
    val error: Color,
    val info: Color
)

private val DarkThemeColors = SafarThemeColors(
    background = SafarBlack,
    surface = SafarDarkSurface,
    surfaceElevated = SafarDarkCard,
    surfaceHighest = SafarDarkElevated,
    primary = SafarGreen,
    primaryDark = SafarGreenDark,
    primaryLight = SafarGreenLight,
    onPrimary = SafarBlack,
    secondary = SafarBlue,
    onSecondary = SafarWhite,
    onBackground = SafarTextPrimary,
    onSurface = SafarTextPrimary,
    onSurfaceVariant = SafarTextSecondary,
    textPrimary = SafarTextPrimary,
    textSecondary = SafarTextSecondary,
    textTertiary = SafarTextTertiary,
    divider = SafarDivider,
    border = SafarBorder,
    success = SafarSuccess,
    warning = SafarWarning,
    error = SafarError,
    info = SafarInfo
)

private val LightThemeColors = SafarThemeColors(
    background = SafarBg,
    surface = SafarWhite,
    surfaceElevated = SafarLightElevated,
    surfaceHighest = SafarWhite,
    primary = SafarGreen,
    primaryDark = SafarGreenDark,
    primaryLight = SafarGreenLight,
    onPrimary = SafarWhite,
    secondary = SafarBlue,
    onSecondary = SafarWhite,
    onBackground = SafarTextDark,
    onSurface = SafarTextDark,
    onSurfaceVariant = SafarTextMuted,
    textPrimary = SafarTextDark,
    textSecondary = SafarTextMuted,
    textTertiary = SafarTextLight,
    divider = SafarDividerLight,
    border = SafarDividerLight,
    success = SafarSuccess,
    warning = SafarWarning,
    error = SafarError,
    info = SafarInfo
)

private val LocalSafarColors = staticCompositionLocalOf { DarkThemeColors }
// ─── SAFAR THEME ACCESSOR OBJECT ──────────────────────────────────────────────
object SafarTheme {
    val colors: SafarThemeColors
        @Composable
        get() = LocalSafarColors.current
    
    val typography: SafarTypographySystem
        get() = SafarTypographySystem
}

// Alias for direct access
typealias SafarTypographySystem = SafarTypography

// ─── THEME COMPOSABLE ─────────────────────────────────────────────────────────
@Composable
fun SafarTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val themeColors = if (darkTheme) DarkThemeColors else LightThemeColors
    
    CompositionLocalProvider(
        LocalSafarColors provides themeColors,
        LocalSafarTypography provides SafarTypography
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            content = content
        )
    }
}
